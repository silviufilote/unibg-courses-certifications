"""Write a program to detect cycles in a directed graph (V vertices, E
edges). When a cycle is detected, return all its vertices. There could
be multiple cycles, it's ok to return only one.

In this lesson we also start using the @property decorator!"""

from collections import deque
from typing import List
import os


class CycleDetector:

    def _set_adm(self, adm):

        self._adm: dict[int, List[int]] = adm
        self._cycle_edges = set()

    def _get_adm(self):

        return self._adm

    def _del_adm(self):

        self._adm = dict()
        self._cycle_edges = set()

    """This is the typical use, but you can do similarly with
    annotations. Type `help(property)` in ipython to read about
    properties."""
    adm = property(
        fget=_get_adm,
        fset=_set_adm,
        fdel=_del_adm,
        doc="The graph adjancency matrix",
    )

    @property
    def cycle_edges(self):

        return self._cycle_edges

    def detect_cycle(self) -> List[int] | None:
        """Detects the presence of a cycle in a directed graph. If a
        cycle is found, it returns the list of its vertices, it
        returns None otherwise.

        Complexity:
            -S: O(V)
            -T: O(V+E)

        """

        # we will perform a sequence of visits
        stack = deque([])
        is_on_stack = {v: False for v in self._adm}
        is_visited = {v: False for v in self._adm}

        for src in self._adm:

            if is_visited[src]:
                continue

            stack.append(src)
            while len(stack) > 0:
                v = stack[-1]  # peek
                if not is_visited[v]:
                    # visit the graph from v
                    is_visited[v] = True
                    is_on_stack[v] = True
                    for dst in self._adm[v]:
                        if not is_visited[dst]:
                            stack.append(dst)
                        elif is_on_stack[dst]:
                            return self._extract_cycle(stack, dst)
                else:
                    is_on_stack[v] = False
                    stack.pop()

        return None

    # HOME PRACTICE: write a recursive version of `detect_cycle()`

    def _extract_cycle(self, stack, dst):

        idx = len(stack) - 1
        while stack[idx] != dst:
            idx -= 1

        cycle = [stack[i] for i in range(idx, len(stack))]

        # save edges in the cycle for Graph2D visualization
        self._cycle_edges.add((cycle[-1], cycle[0]))
        for pos in range(len(cycle) - 1, 0, -1):
            self._cycle_edges.add((cycle[pos - 1], cycle[pos]))

        return cycle


# graph visualization
if __package__:
    from .helpers.graph_printer import Graph2D
else:
    from helpers.graph_printer import Graph2D

# adjacency matrices
adms = [
    {
        0: [1, 2, 3],
        1: [4],
        2: [],
        3: [2],
        4: [2],
    },
    {
        0: [1, 2, 3],
        1: [4],
        2: [],
        3: [2],
        4: [1],
    },
    {
        0: [],
        1: [2],
        2: [1],
    },
    {
        0: [],
        1: [2],
        2: [2],
    },
    {
        0: [],
        1: [2],
        2: [0],
    },
    {
        0: [1, 3],
        1: [4],
        2: [1],
        3: [2],
        4: [3],
    },
    {
        0: [2],
        1: [4],
        2: [1, 3],
        3: [],
        4: [0],
    },
]

# instantiates a cycle detector object
cycle_detector = CycleDetector()

# run tests
for graph, adm in enumerate(adms):

    cycle_detector.adm = adm  # update property
    print(f"Graph {graph}, cycles? {cycle_detector.detect_cycle()}")
    Graph2D(
        cycle_detector.adm,
        highlighted_edges=cycle_detector.cycle_edges,
        highlighting_descr="cycle",
    ).visualize(directed=True)
    os.system("clear")
