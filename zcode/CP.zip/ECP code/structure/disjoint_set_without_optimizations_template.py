""""UNION-FIND - Without Optimizations
 """

E = set([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])
L = [(13, 14), (12, 13), (11, 12), (10, 11), (7, 8), (6, 7), (5, 6), (5, 10),
     (1, 2), (3, 4), (9, 10), (0, 1), (1, 4)]
P = {}
n = len(E)
representative = [-1 for _ in range(n)]


def make_set_wo(e):

    # ...
    pass


def find_wo(e):

    # ...
    pass


def union_wo(e1, e2):

    # ...
    pass


if __package__:
    from .helpers.disjoint_set_printer import DisjointSet2D
else:
    from helpers.disjoint_set_printer import DisjointSet2D

# init partitions
for e in E:
    make_set_wo(e)

# update partitions
for e1, e2 in L:
    DisjointSet2D(representative).visualize(stop_ui=False)
    print(f"link: {e1, e2}")
    union_wo(e1, e2)
    DisjointSet2D(representative).visualize(latest_link=(e1, e2))
