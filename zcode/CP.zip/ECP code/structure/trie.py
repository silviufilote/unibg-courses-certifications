"""Trie example. You are given a vocabulary and a prefix string. Find
all the words in the vocabulary that start with the given prefix."""


class Node:

    def __init__(self, children: dict, is_term: bool):

        self.children = children
        self.is_term = is_term


class Trie():

    def __init__(self):

        self._trie = None

    def index(self, words: list):
        """
        Creates a Trie given a set of words

        Complexity:
        
            -S: O(NL) [where N is the number of words, and L is the length of the longest word]
            -T: O(NL)
        """

        # start from an empty Trie
        self._trie = Node(children={}, is_term=False)
        for word in words:
            # perform a visit to the Trie to insert each word
            cn = self._trie
            for char in word:
                if not char in cn.children:
                    cn.children[char] = Node(
                        children={},
                        is_term=False,
                    )
                cn = cn.children[char]
            # memorize word
            cn.is_term = True

    def autocomplete_prefix(self, prefix):
        """Given a prefix, returns all the completion candidates in
        the Trie

        Complexity:
        
            -T: O(P + N(L-P)) [where P is the length of the prefix, L
             is the length of the longest word, N is the number of
             words.
            -S: O(N + L - P)

        """

        cn = self._trie
        for char in prefix:
            if cn is None or not (char in cn.children):
                return []
            cn = cn.children[char]
        # prefix exists, return all the completions
        return self._print_completions(cn, prefix)

    def _print_completions(self, cn, prefix):

        print("Completions found:")

        # [(suffix, prefix position in the suffix chain)]
        suffix_chain = [(prefix, None)]
        # [(current node, node position in the suffix chain, node_explored)]
        stack = [(cn, 0, False)]
        while len(stack) > 0:
            stack_pos = len(stack)
            cn, sc_pos, node_explored = stack[-1]
            if node_explored:
                # pop from both the stacks
                suffix_chain.pop(), stack.pop()
                continue
            if cn.is_term:
                print(f"\t{self._concatenate_suffixes(suffix_chain, sc_pos)}")
            for char in cn.children:
                suffix_chain.append((char, sc_pos))
                stack.append((cn.children[char], len(suffix_chain) - 1, False))
            # mark the current node as explored
            stack[stack_pos - 1] = (cn, sc_pos, True)

    def _concatenate_suffixes(self, suffix_chain, sc_pos):

        parts = []
        while sc_pos != None:
            parts.append(suffix_chain[sc_pos][0])
            sc_pos = suffix_chain[sc_pos][1]

        return "".join(parts[::-1])


# a collection of flowers
flowers = [
    "ACONITUM",
    "ALYSSUM",
    "AGAPANTHUS",
    "ALCHEMILLA",
    "ALSTROEMERIA",
    "ALYSSUM",
    "AMARANTHUS",
    "AMARYLLIS",
    "ANEMONE",
    "ANGELONIA",
    "ANTHURIUM",
    "ANTIRRHINUM",
    "DAHLIA",
    "IRIS",
    "IRIS BLUE",
    "ORCHID",
]
flowers.sort()
print("Flowers:")
for f in flowers:
    print(f"\t{f}")
print()

trie = Trie()
trie.index(flowers)

# import runner and printer
if __package__ is None:
    from .helpers.helper import Runner
    from .helpers.trie_printer import Trie2D
else:
    from helpers.helper import Runner
    from helpers.trie_printer import Trie2D

# get a runner for l
run = Runner(trie).get()

for p in ("A", "AC", "AN", "ORCHID A", "Z", "IRI"):
    run("autocomplete_prefix", prefix=p)

# visualize trie
Trie2D(trie).visualize()
