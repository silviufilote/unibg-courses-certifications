""""UNION-FIND - Union By Rank
"""

E = set([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])
L = [
    (0, 1),  # case A
    (2, 1),  # case A
    (3, 2),  # case A    
    (4, 3),  # case A
    (4, 5),  # case A
    (5, 6),  # case A
    (7, 8),  # case B 
    (9, 10),  # case B
    (7, 9),  # case B
    (11, 12),  # case B
    (13, 14),  # case B
    (11, 13),  # case B
    (7, 13),  # case B
]
P = {}
n = len(E)
representative = [-1 for _ in range(n)]
rank = [-1 for _ in range(n)]


def make_set_ubr(e):

    representative[e] = e
    rank[e] = 0


def find_ubr(e):

    while e != representative[e]:
        e = representative[e]
    return e


def union_ubr(e1, e2):

    # ...
    pass


if __package__:
    from .helpers.disjoint_set_printer import DisjointSet2D
else:
    from helpers.disjoint_set_printer import DisjointSet2D

# init partitions
for e in E:
    make_set_ubr(e)

# update partitions
for e1, e2 in L:
    union_ubr(e1, e2)

DisjointSet2D(
    representatives=representative,
    rank=rank,
).visualize()
