from io import StringIO


class Node:

    def __init__(self, key, next_e=None):

        self.key: str = key
        self.next_e: Node | None = next_e

    def __str__(self):

        return f"{self.key}"


class Queue:

    def __init__(self):

        self._head: Node | None = None
        self._tail: Node | None = None
        self._len = 0

    def __len__(self):

        return self._len

    def push(self, key):

        n = Node(key=key)
        # extend the tail
        if self._len == 0:
            self._tail = n
            self._head = n
        else:
            self._tail.next_e = n
            self._tail = self._tail.next_e
        # set the head if the queue is empty
        self._len += 1

    def pop(self):

        if self._len == 0:
            return None
        # get the key to return
        key = self._head.key
        # consume a node
        self._head = self._head.next_e
        self._len -= 1
        # set the tail if the queue is empty
        if self._len == 0:
            self._tail = None
        return key

    def __str__(self) -> str:

        objstr = StringIO()
        objstr.write(f"[len: {self._len}]")
        n = self._head
        while n:
            objstr.write(f"->{n.key}")
            n = n.next_e
        objstr.write("->None")
        return objstr.getvalue()


# import the test helper
if __package__ is None:
    from .helpers.helper import Runner
else:
    from helpers.helper import Runner

# init
queue = Queue()
run = Runner(queue).get()

# push
for key in ["Bob", "Alice", "Eve", "Sarah"]:
    run("push", key=key)

# pop
for _ in range(5):
    run("pop")
