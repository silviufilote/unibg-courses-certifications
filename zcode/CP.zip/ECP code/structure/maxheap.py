import math
from io import StringIO
import random
from typing import List


class MaxHeap:
    """Max heap implementation"""

    def __init__(self, sequence: List[int]):

        self._heap = sequence
        self._n = len(sequence)
        self._build_heap()

    def __len__(self):

        return self._n

    def __str__(self):

        hp_str = StringIO()
        idx_str = StringIO()
        hp_str.write("heap\t[")
        idx_str.write("\tidx\t[")
        for idx, e in enumerate(self._heap):
            hp_str.write("{:4}".format(e))
            idx_str.write("{:4}".format(idx))
        hp_str.write("  ]\n")
        idx_str.write("  ]")
        hp_str.write(idx_str.getvalue())
        return hp_str.getvalue()

    def _build_heap(self):

        # no need to sift half of the leaves
        start = self._n - math.floor(self._n / 2)
        # build the max heap
        for i in range(start, -1, -1):
            self._heapify(i)

    def _swap(self, i, j):

        self._heap[i], self._heap[j] = self._heap[j], self._heap[i]

    def _heapify(self, i):

        # siftDown
        while True:
            largest = i  # root
            l = 2 * i + 1  # left child
            r = 2 * i + 2  # right child
            if l < self._n:  # 1st out-of-bound check
                if self._heap[l] > self._heap[i]:
                    largest = l
            if r < self._n:  # 2nd out-of-bound check
                if self._heap[r] > self._heap[largest]:
                    largest = r
            if largest != i:
                # move the largest key upward
                self._swap(i, largest)
                # keep sifting
                i = largest
            else:
                # stop sifting
                break

    def validate(self):
        """Return `True` for a valid Max Heap"""

        for i in range(self._n):
            l = 2 * i + 1
            if l < self._n:
                if self._heap[l] > self._heap[i]:
                    return False
            r = 2 * i + 2
            if r < self._n:
                if self._heap[r] > self._heap[i]:
                    return False
        return True

    def push(self, key):
        """Push a new element to the Max Heap"""

        self._heap.append(key)
        self._n += 1
        # sift up
        child = self._n - 1
        while child > 0:
            parent = math.floor((child - 1) / 2)
            if self._heap[child] > self._heap[parent]:
                self._swap(parent, child)
                child = parent
            else:
                break

    def pop(self):
        """Pop the greatest element from the Max Heap"""

        if self._n < 1:
            return None
        # put the greatest key at the end of the backing array
        self._swap(0, self._n - 1)
        self._n -= 1
        # restore the heap property
        p = 0
        while p < self._n:
            largest = p
            l = 2 * p + 1
            r = 2 * p + 2
            if l < self._n:
                if self._heap[l] > self._heap[p]:
                    largest = l
            if r < self._n:
                if self._heap[r] > self._heap[largest]:
                    largest = r
            if largest != p:
                # sift down
                self._swap(largest, p)
                p = largest
            else:
                break
        # pop the greatest key from the backing array
        return self._heap.pop()


if __package__:
    from .helpers.helper import Runner
else:
    from helpers.helper import Runner

# a sequence with an odd or even length
keys = [i * 10 for i in range(10 + random.randint(0, 3))]
random.shuffle(keys)
print(f"keys:\t\t{keys}")

# build a max heap from the sequence of keys
max_heap = MaxHeap(keys)
run = Runner(max_heap).get()

# initial validation
run("validate")

# push new keys into the heap
for key in [-1, 150, 18, 55]:
    run("push", key=key)

# validate after push
run("validate")

# pop some keys
for i in range(3):
    run("pop")

# validation after pop
run("validate")
