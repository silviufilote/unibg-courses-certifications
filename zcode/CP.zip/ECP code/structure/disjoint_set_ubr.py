""""UNION-FIND - Union By Rank

Compared to the approach without optimizations, this version
guarantees that the representative is always found with a logarithmic
number of operations"""

E = set([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])
L = [
    (0, 1),  # case A
    (2, 1),  # case A
    (3, 2),  # case A    
    (4, 3),  # case A
    (4, 5),  # case A
    (5, 6),  # case A
    (7, 8),  # case B 
    (9, 10),  # case B
    (7, 9),  # case B
    (11, 12),  # case B
    (13, 14),  # case B
    (11, 13),  # case B
    (7, 13),  # case B
]
P = {}
n = len(E)
representative = [-1 for _ in range(n)]
rank = [-1 for _ in range(n)]


def make_set_ubr(e):

    representative[e] = e
    rank[e] = 0


def find_ubr(e):

    while e != representative[e]:
        e = representative[e]
    return e


def union_ubr(e1, e2):
    """With this configuration, the rank limits the height of the
    virtual tree connecting the elements (watch the 2D
    visualization). When N is the number of elements, `find` takes
    O(log(N)) time

    """

    e1 = find_ubr(e1)
    e2 = find_ubr(e2)
    if e1 == e2:
        return
    if rank[e1] == rank[e2]:
        rank[e1] += 1
        representative[e2] = e1
    elif rank[e1] > rank[e2]:
        representative[e2] = e1
    else:
        representative[e1] = e2


if __package__:
    from .helpers.disjoint_set_printer import DisjointSet2D
else:
    from helpers.disjoint_set_printer import DisjointSet2D

# init partitions
for e in E:
    make_set_ubr(e)

# update partitions
for e1, e2 in L:
    union_ubr(e1, e2)

DisjointSet2D(
    representatives=representative,
    rank=rank,
).visualize()
