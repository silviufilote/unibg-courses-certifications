from io import StringIO


class Node:

    def __init__(self, key, next_e=None):

        self.key: str = key
        self.next_e: Node | None = next_e

    def __str__(self):

        return f"{self.key}"


class Stack:

    def __init__(self):

        self._head: Node | None = None
        self._len: int = 0

    def push(self, key):

        nh = Node(key=key, next_e=self._head)
        self._head = nh
        self._len += 1

    def len(self):

        return self._len

    def pop(self):

        if self._len == 0:
            return None
        key = self._head.key
        self._head = self._head.next_e
        self._len -= 1
        return key

    def __str__(self):

        objstr = StringIO()
        objstr.write(f"[len: {self._len}] ")
        h = self._head
        while h:
            objstr.write(f"->{h.key}")
            h = h.next_e
        objstr.write("->None")
        return objstr.getvalue()


if __package__ is None:
    from .helpers.helper import Runner
else:
    from helpers.helper import Runner

# configure test
stack = Stack()
run = Runner(stack).get()

# push
for key in ["Bob", "Alice", "Eve", "Sarah"]:
    run("push", key=key)

# pop
for _ in range(5):
    run("pop")
