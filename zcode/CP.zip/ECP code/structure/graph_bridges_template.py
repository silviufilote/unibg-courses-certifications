"""A bridge is defined as an edge which, when removed, makes the graph
disconnected (i.e., it increases the number of connected
components). Implement a program to find all the bridges in an
undirected graph with V vertices and E edges.

"""

from collections import deque
import os


class BridgeFinder:

    def __init__(self):

        self._adm = dict()
        self._bridges: set[tuple] = set()

    @property
    def adm(self):

        return self._adm

    @property
    def bridges(self):

        return self._bridges

    @adm.setter
    def adm(self, adm):

        if adm is None or len(adm) == 0:
            self._adm = dict()
            return

        self._adm = adm
        self._make_undirected()
        self._bridges = set()

    def _make_undirected(self):

        # revert edges
        radm = {v: [] for v in self._adm}
        for v in self._adm:
            for dst in self._adm[v]:
                radm[dst].append(v)

        # merge adm and radm
        for v in self._adm:
            self._adm[v].extend(radm[v])

    def _print_bridge(self, a, b):

        if a > b:
            a, b = b, a
        print(f"\t{a} >==< {b}")

        self._bridges.add((a, b))

    def find(self):
        """Finds all the bridges in the graph.
        """

        print("Bridges:")

        # ...

    def find_iterative(self):
        """
        Iterative solution to find bridges
        """

        print("Bridges (iterative version):")

        # ...


adms = [{
    0: [1],
    1: [2, 3],
    2: [0],
    3: [4],
    4: [5],
    5: [3],
    6: [5, 7],
    7: [8],
    8: [9],
    9: [6, 10],
    10: []
}, {
    0: [1],
    1: [2],
    2: [0],
}, {
    0: [1],
    1: [2],
    2: [3],
    3: [4],
    4: [0],
}, {
    0: [1],
    1: [2],
    2: [3],
    3: [],
    4: [],
}, {
    0: [1],
    1: [0],
    2: [],
    3: [4, 6],
    4: [5],
    5: [3],
    6: [],
}, {
    0: [1],
    1: [],
    2: [3],
    3: [],
}, {
    0: [],
    1: [2],
    2: [],
    3: [4],
    4: [],
}, {
    0: [1, 2, 7],
    1: [2, 3, 6],
    2: [4],
    3: [4, 5],
    4: [6],
    5: [6, 7],
    6: [8, 7],
    7: [],
    8: [],
}, {
    0: [1, 2, 7],
    1: [2, 3, 6],
    2: [4, 5],
    3: [4, 5],
    4: [6, 7],
    5: [6, 7],
    6: [7],
    7: [],
}, {
    0: [1, 2, 3],
    1: [0, 2, 3],
    2: [0, 1, 3],
    3: [0, 1, 2],
}]

# graph visualization
if __package__:
    from .helpers.graph_printer import Graph2D
else:
    from helpers.graph_printer import Graph2D

# build resolver
bridge_finder = BridgeFinder()

# tests
for adm in adms:
    bridge_finder.adm = adm
    bridge_finder.find()
    bridge_finder.find_iterative()
    Graph2D(
        bridge_finder.adm,
        highlighted_edges=bridge_finder.bridges,
        highlighting_descr="bridge",
    ).visualize(
        directed=False,
        weighted=False,
    )
    os.system("clear")
