"""Directed graph with V vertices and E edges"""

from collections import deque

# adjacency map: source -> [list of destinations]
adm = {
    0: [1, 2, 3, 5],  # from vertex 0 to vertices 1, 2, 3, 5
    1: [4, 5],
    2: [7],
    3: [2],
    4: [5],
    5: [0, 1, 6],
    6: [7],
    7: [],
    8: [],
    9: [10],
    10: [11],
    11: [9],
}


def bfs(adm, source):
    """Explores a directed graph with a BFS

    Args:
        adm (Dict[int, List[int]]): adjacency map
        source (int): source node

    BFS
    
    - the path found by breadth first search to any node is the
      shortest path to that node, i.e. the path that contains the
      smallest number of edges
    - O(V+E) time
    - O(V) space

    """

    print("BFS")

    # distances (from the source)
    distances = {v: None for v in adm.keys()}
    # visited vertices
    colored = {v: False for v in adm.keys()}

    # exploration queue
    q = deque([source])
    colored[source] = True
    distances[source] = 0

    while len(q) != 0:
        v = q.popleft()
        for dst in adm[v]:
            if not colored[dst]:
                q.append(dst)
                colored[dst] = True
                distances[dst] = distances[v] + 1

    print(f"Distances from {source}:")
    for vertex, distance in distances.items():
        print(f"\t{vertex}: {distance}")


def dfs(adm, source):
    """Explores a directed graph with a DFS

    Args:
        adm (Dict[int, List[int]]): adjacency map
        source (int): source node
    
    DFS

    - finds the lexicographical first path in the graph from a source
      to each vertex (it will also find the shortest paths in a tree,
      because only one path exists for each vertex in that case)
    - T: O(V+E)
    - S: O(V)

    """

    print("DFS")

    # visited vertices
    colored = {v: False for v in adm.keys()}

    # exploration stack
    s = deque([(source, 0)])
    colored[source] = True

    while len(s) != 0:
        v, e = s[-1]
        # are there edges from v to be explored?
        if e <= len(adm[v]) - 1:
            # update next edge to be explored from v
            s[-1] = (v, e + 1)
            # check the current edge from v
            dst = adm[v][e]
            if not colored[dst]:
                s.append((dst, 0))
                colored[dst] = True
        else:
            s.pop()

    print(
        f"Unreachable vertices: {[v for v in colored.keys() if not colored[v]] }"
    )


# breadth-first search
bfs(adm, 0)

print("---")

# depth-first search
dfs(adm, 0)

# graph visualization
if __package__:
    from .helpers.graph_printer import Graph2D
else:
    from helpers.graph_printer import Graph2D

Graph2D(adm).visualize(directed=True)
