"""You are given an undirected weighted graph with V vertices and E
edges. Weights are non-negative and represent the distance between two
vertices. You are also given a starting vertex src. Find the shortest
path from src to all the other vertices"""

from typing import List
from collections import deque
import heapq
import os


class Dijkstra:

    def _set_adm(self, adm):

        self._adm: dict[int, List[tuple[int, int]]] = adm
        self._make_undirected()
        self._n: int = len(adm)
        self._previous = {v: None for v in self._adm}

    def _get_adm(self):

        return self._adm

    def _del_adm(self):

        self._adm = dict()
        self._n = 0

    adm = property(
        fget=_get_adm,
        fset=_set_adm,
        fdel=_del_adm,
        doc="The graph adjancency matrix",
    )

    def _make_undirected(self):

        # reverse
        radm = {v: [] for v in self._adm}
        for src in self._adm:
            edges = self._adm[src]
            for dst, distance in edges:
                radm[dst].append((src, distance))
        # merge adm and radm
        for v in self._adm:
            self._adm[v].extend(radm[v])

    def shortest_paths(self, src):
        """Computes the shortest path between src and all other
        vertices in the graph
        """

    def extract_path(self, src, dst):
        """Extracts the path between src and dst"""

        if self._previous[dst] is None:
            return []

        path = deque([])
        while dst != src:
            path.appendleft(dst)
            dst = self._previous[dst]
        path.appendleft(dst)
        return path


adms = [
    {
        # src: [(dst1, weight1)...]
        0: [(1, 3), (2, 1), (3, 2)],
        1: [(4, 4)],
        2: [],
        3: [(2, 7), (4, 1)],
        4: [(5, 1)],
        5: [(0, 5), (6, 4)],
        6: [(7, 12)],
        7: [],
        8: [],
    },
    {
        0: [(1, 1), (6, 100)],
        1: [(2, 1), (6, 98)],
        2: [(3, 1), (6, 96)],
        3: [(4, 1), (6, 94)],
        4: [(5, 1), (6, 92)],
        5: [(6, 1), (6, 90)],
        6: [],
    },
]

path_finder = Dijkstra()

# graph visualization
if __package__:
    from .helpers.graph_printer import Graph2D
else:
    from helpers.graph_printer import Graph2D

for adm in adms:
    path_finder.adm = adm

    # compute shortest paths
    src = 0
    path_finder.shortest_paths(src=src)

    # print shortest paths
    for dst in [v for v in path_finder.adm if v != src]:
        print(f"path from {src} to {dst}:",
              "->".join(map(str, path_finder.extract_path(src, dst))))

    Graph2D(path_finder.adm).visualize(directed=False, weighted=True)
    os.system("clear")
