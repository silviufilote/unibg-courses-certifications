"""We already have an implementation of Heap in Python:

import heapq

It's a Min Heap implementation. Remember that you can invert the sign
of the keys when a Max Heap is required"""

import random
import heapq

# let's start from a list of keys
l = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
l

# key shuffle
random.shuffle(l)
l

# transform the list into a Min Heap
heapq.heapify(l)  # in-place, in linear time O(n)
l

# push one key keeping the heap variant O(logN)
item = -1
heapq.heappush(l, item)
l

# access the smallest key without pop
l[0]

# pop one key keeping the heap variant O(logN)
heapq.heappop(l)
l
# remember that this can raise an `Index Error` when the heap is empty

# merge two sorted sequences
sorted_list1 = [1, 5, 8]
sorted_list2 = [2, 4, 7]
sorted_list1, sorted_list2
heapq.merge(sorted_list1, sorted_list2)  # remember: merge returns an iterator
list(heapq.merge(sorted_list1, sorted_list2))

# k-largest keys from an unordered iterable
k = 3
l = [1, 2, 3, 4, 5, 6, 7, 8, 9]
random.shuffle(l)
l
heapq.nlargest(k, l)

# k-smallest keys from an unordered iterable
k = 3
l = [1, 2, 3, 4, 5, 6, 7, 8, 9]
random.shuffle(l)
l
heapq.nsmallest(k, l)
