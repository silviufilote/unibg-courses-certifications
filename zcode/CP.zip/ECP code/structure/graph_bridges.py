"""A bridge is defined as an edge which, when removed, makes the graph
disconnected (i.e., it increases the number of connected
components). Implement a program to find all the bridges in an
undirected graph with V vertices and E edges.

"""

from collections import deque
import os


class BridgeFinder:

    def __init__(self):

        self._adm = dict()
        self._bridges: set[tuple] = set()

    @property
    def adm(self):

        return self._adm

    @property
    def bridges(self):

        return self._bridges

    @adm.setter
    def adm(self, adm):

        if adm is None or len(adm) == 0:
            self._adm = dict()
            return

        self._adm = adm
        self._make_undirected()
        self._bridges = set()

    def _make_undirected(self):

        # revert edges
        radm = {v: [] for v in self._adm}
        for v in self._adm:
            for dst in self._adm[v]:
                radm[dst].append(v)

        # merge adm and radm
        for v in self._adm:
            self._adm[v].extend(radm[v])

    def _print_bridge(self, a, b):

        if a > b:
            a, b = b, a
        print(f"\t{a} >==< {b}")

        self._bridges.add((a, b))

    def _dfs(self, vertex, previous):

        self._visited[vertex] = True
        self._discovery[vertex] = self._low[vertex] = self._time
        self._time += 1
        for dst in self._adm[vertex]:
            if dst == previous:
                continue
            if self._visited[dst]:
                self._low[vertex] = min(self._low[vertex],
                                        self._discovery[dst])
            else:
                self._dfs(dst, vertex)
                self._low[vertex] = min(self._low[vertex], self._low[dst])
                if self._low[dst] > self._discovery[vertex]:
                    self._print_bridge(vertex, dst)

    def find(self):
        """Finds all the bridges in the graph.

        Complexity:
            -T: O(V+E)
            -S: O(V)
        """

        if len(self._adm) == 0:
            return

        print("Bridges:")

        self._time = 0
        # discovery time for each vertex
        self._discovery = {v: -1 for v in self._adm}
        # vertex low time
        self._low = {v: float("inf") for v in self._adm}
        # visited vertices
        self._visited = {v: False for v in self._adm}

        # let's perform a sequence of DFS visits on the graph
        for origin in self._adm:
            self._time += 1
            if self._visited[origin]:
                continue
            self._dfs(origin, previous=None)

    def find_iterative(self):
        """
        Iterative solution to find bridges
        """

        print("Bridges (iterative version):")

        time = 0
        discovery = {v: -1 for v in self._adm}
        low = {v: float("inf") for v in self._adm}
        visited = {v: False for v in self._adm}

        for o in self._adm:

            if visited[o]:
                continue

            # stack
            s = deque([])
            # (previous, current, edge, return)
            s.append((None, o, 0, False))
            while len(s) > 0:
                p, c, e, ret = s[-1]
                if ret:
                    # return from vertex dst
                    dst = self._adm[c][e]
                    low[c] = min(low[c], low[dst])
                    if low[dst] > discovery[c]:
                        self._print_bridge(c, dst)
                    s[-1] = (p, c, e + 1, False)
                dst = None
                if e <= len(self._adm[c]) - 1:
                    dst = self._adm[c][e]
                else:
                    s.pop()
                    continue
                if dst == p:
                    s[-1] = (p, c, e + 1, False)
                    continue
                if visited[dst]:
                    low[c] = min(low[c], discovery[dst])
                    s[-1] = (p, c, e + 1, False)
                    continue
                else:
                    time += 1
                    discovery[dst] = time
                    low[dst] = time
                    visited[dst] = True
                    s[-1] = (p, c, e, True)
                    s.append((c, dst, 0, False))


adms = [{
    0: [1],
    1: [2, 3],
    2: [0],
    3: [4],
    4: [5],
    5: [3],
    6: [5, 7],
    7: [8],
    8: [9],
    9: [6, 10],
    10: []
}, {
    0: [1],
    1: [2],
    2: [0],
}, {
    0: [1],
    1: [2],
    2: [3],
    3: [4],
    4: [0],
}, {
    0: [1],
    1: [2],
    2: [3],
    3: [],
    4: [],
}, {
    0: [1],
    1: [0],
    2: [],
    3: [4, 6],
    4: [5],
    5: [3],
    6: [],
}, {
    0: [1],
    1: [],
    2: [3],
    3: [],
}, {
    0: [],
    1: [2],
    2: [],
    3: [4],
    4: [],
}, {
    0: [1, 2, 7],
    1: [2, 3, 6],
    2: [4],
    3: [4, 5],
    4: [6],
    5: [6, 7],
    6: [8, 7],
    7: [],
    8: [],
}, {
    0: [1, 2, 7],
    1: [2, 3, 6],
    2: [4, 5],
    3: [4, 5],
    4: [6, 7],
    5: [6, 7],
    6: [7],
    7: [],
}, {
    0: [1, 2, 3],
    1: [0, 2, 3],
    2: [0, 1, 3],
    3: [0, 1, 2],
}]

# graph visualization
if __package__:
    from .helpers.graph_printer import Graph2D
else:
    from helpers.graph_printer import Graph2D

# build resolver
bridge_finder = BridgeFinder()

# tests
for adm in adms:
    bridge_finder.adm = adm
    bridge_finder.find()
    bridge_finder.find_iterative()
    Graph2D(
        bridge_finder.adm,
        highlighted_edges=bridge_finder.bridges,
        highlighting_descr="bridge",
    ).visualize(
        directed=False,
        weighted=False,
    )
    os.system("clear")
