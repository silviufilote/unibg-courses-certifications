import copy
from random import shuffle, randint
"""Adelson-Velsky Landis Tree (AVL)"""


class AVLNode:

    def __init__(self, key):

        if key is None or not isinstance(key, int) or key < 0:
            raise RuntimeError(
                "Invalid key found, only non-negative integers are accepted")

        self._key: int = key
        self._duplicates: int = 1
        self._left: None | AVLNode = None
        self._right: None | AVLNode = None
        self._height: int = 1

    def balance_factor(self) -> int:
        """Returns the balance factor of the tree"""

        lh = 0 if not self._left else self._left._height
        rh = 0 if not self._right else self._right._height

        return lh - rh

    @staticmethod
    def height(node) -> int:

        if node is None:
            return 0
        elif not isinstance(node, AVLNode):
            raise RuntimeError(f"Undefined `height` for type {type(node)}")

        return node._height


class AVLTree:

    def __init__(self, key):

        self._head: AVLNode = AVLNode(key)

    def get_root(self):

        return self._head

    @staticmethod
    def rot_left(root):
        pass

    @staticmethod
    def rot_right(root):
        pass

    def insert(self, key):
        """Inserts a new key ensuring that the tree remains balanced"""

        self._head = AVLTree._insert(self._head, key)

    @staticmethod
    def _insert(tree: AVLNode, key) -> AVLNode:
        pass

    def delete(self, key):
        """Deletes a key, it also guarantees that tree will be
        balanced after deletion. No errors are raised in case the key
        is not found"""

        self._head = AVLTree._delete(self._head, key)

    @staticmethod
    def _delete(tree: AVLNode | None, key, remove_node=False):
        pass


if __package__:
    from .helpers.tree_printer import BinTree2D
else:
    from helpers.tree_printer import BinTree2D

print("Uncomment lines in the code to visualize the impact " \
      + "of insert and delete operations")

# create random keys (with repetitions)
keys = [randint(0, 48) for _ in range(64)]

# shuffle keys
shuffle(keys)

# create the avl tree
tree = AVLTree(keys[0])

# insert key
for key in keys[1:]:
    print(f"Insert key {key}...")
    starting_tree = copy.deepcopy(tree)
    # BinTree2D(starting_tree.get_root()).visualize(stop_ui=False)
    tree.insert(key)
    # BinTree2D(tree.get_root()).visualize()

# delete key (1)
non_existent_key = -1
print("Delete non-existent key ...")
tree.delete(non_existent_key)
print(f"...no errors")

# delete key (2)
deleted_keys = keys[:10]
for key in deleted_keys:
    print(f"Delete key {key}...")
    starting_tree = copy.deepcopy(tree)
    # BinTree2D(starting_tree.get_root()).visualize(stop_ui=False)
    tree.delete(key)
    # BinTree2D(tree.get_root()).visualize()
