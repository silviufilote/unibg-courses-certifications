import math
from io import StringIO
import random
from typing import List


class MaxHeap:
    """Max heap implementation"""

    def __init__(self, sequence: List[int]):

        self._heap = sequence
        self._n = len(sequence)
        self._build_heap()

    def __len__(self):

        return self._n

    def __str__(self):

        hp_str = StringIO()
        idx_str = StringIO()
        hp_str.write("heap\t[")
        idx_str.write("\tidx\t[")
        for idx, e in enumerate(self._heap):
            hp_str.write("{:4}".format(e))
            idx_str.write("{:4}".format(idx))
        hp_str.write("  ]\n")
        idx_str.write("  ]")
        hp_str.write(idx_str.getvalue())
        return hp_str.getvalue()

    def _swap(self, i, j):

        self._heap[i], self._heap[j] = self._heap[j], self._heap[i]

    def _build_heap(self):

        pass

    def _heapify(self, i):

        pass

    def validate(self):
        """Return `True` for a valid Max Heap"""

        pass

    def push(self, key):
        """Push a new element to the Max Heap"""

        pass

    def pop(self):
        """Pop the greatest element from the Max Heap"""

        pass


if __package__:
    from .helpers.helper import Runner
else:
    from helpers.helper import Runner

# a sequence with an odd or even length
keys = [i * 10 for i in range(10 + random.randint(0, 3))]
random.shuffle(keys)
print(f"keys:\t\t{keys}")

# build a max heap from the sequence of keys
max_heap = MaxHeap(keys)
run = Runner(max_heap).get()

# initial validation
run("validate")

# push new keys into the heap
for key in [-1, 150, 18, 55]:
    run("push", key=key)

# validate after push
run("validate")

# pop some keys
for i in range(3):
    run("pop")

# validation after pop
run("validate")
