from collections import deque
import matplotlib.pyplot as plt
import networkx as nx


class Graph2D:

    def __init__(self, adm, highlighted_edges: set[tuple] = None, highlighting_descr: str = None):
        
        self._adm = adm
        self._directed = True
        self._weighted = False
        self._highlighted_edges = set() if not highlighted_edges else highlighted_edges
        self._highlighting_descr = highlighting_descr

    def visualize(
        self,
        directed=True,
        weighted=False,
        stop_ui=True,
    ):

        self._directed = directed
        self._weighted = weighted

        # get the 2d graph and other node attributes
        g, edge_labels = self._build_repr_graph()

        # plot
        # set figure color
        fig, ax = plt.subplots()
        # 2D graph plot (tree layout)
        try:
            nodes_coords = nx.planar_layout(g)
        except nx.NetworkXException as _:
            nodes_coords = nx.spring_layout(g)
        # nodes
        nx.draw_networkx_nodes(
            g,
            nodes_coords,
            node_color='limegreen',
            node_size=1500,
        )
        # edges
        edge_colors = ['limegreen' if not e in self._highlighted_edges else 'pink' for e in g.edges]
        nx.draw_networkx_edges(
            g,
            nodes_coords,
            edge_color=edge_colors,
            node_size=1500,
            width=3,
            arrows=True,
            connectionstyle='arc3, rad = 0.1' if directed else 'arc',
        )
        # node names
        nx.draw_networkx_labels(
            g,
            nodes_coords,
            font_color="white",
            font_weight='bold',
        )
        # edge labels
        if self._weighted and not self._directed:
            nx.draw_networkx_edge_labels(
                g,
                nodes_coords,
                edge_labels=edge_labels,
                font_color="red",
                font_weight='bold',
            )

        # change background color
        ax.set_facecolor("black")
        if len(self._highlighted_edges) > 0:
            plt.text(0, 1, f"\u26AB{self._highlighting_descr}", color="pink", fontsize="xx-large",transform=ax.transAxes, )
            
        fig.set_facecolor("black")
        # show plot
        if not stop_ui:
            plt.draw()
        else:
            plt.show()

    def _build_repr_graph(self):

        # initialize a graph
        g = None
        edge_labels = dict()
        match (self._directed, self._weighted):
            case (True, False):
                g = nx.DiGraph()
            case (False, True):
                g = nx.Graph()
            case (False, _):
                g = nx.Graph()

        # add vertices
        for v in self._adm:
            g.add_node(v)

        # add edges
        for src in self._adm.keys():
            match (self._directed, self._weighted):
                case (True, False):
                    for dst in self._adm[src]:
                        g.add_edge(src, dst)                
                case (False, True):
                    for dst, weight in self._adm[src]:
                        g.add_edge(src, dst, weight=weight)
                        edge_labels[(src, dst)] = str(weight)
                case (False, _):
                    for dst in self._adm[src]:
                        g.add_edge(src, dst)                                

        return g, edge_labels
