import matplotlib.pyplot as plt
import networkx as nx
from math import log2
from networkx.drawing.nx_agraph import graphviz_layout


class DisjointSet2D:

    def __init__(self, representatives, rank=None):

        self._representatives = representatives
        self._rank = rank

    def visualize(self, stop_ui=True, latest_link=None):

        # get the 2d graph and other node attributes
        g, vertices_with_rank = self._build_repr_graph()

        # plot
        # set figure color
        fig, ax = plt.subplots()
        # 2D graph plot
        nodes_coords = graphviz_layout(g, prog='dot', args='-Grankdir="BT"')
        # nodes
        nx.draw_networkx_nodes(
            g,
            nodes_coords,
            node_color="white",
            node_size=1000,
        )
        # edges
        nx.draw_networkx_edges(
            g,
            nodes_coords,
            edge_color='white',
            arrows=True,
            width=2,
            connectionstyle='arc3',
        )
        # node names
        nx.draw_networkx_labels(
            g,
            nodes_coords,
            font_color="blue",
            font_weight='bold',
        )
        # draw rank info
        if self._rank:
            labels_pos = dict()
            for node, coords in nodes_coords.items():
                labels_pos[node] = (
                    coords[0],
                    coords[1] - 4.7,
                )
            nx.draw_networkx_labels(
                g,
                labels_pos,
                labels={k: f"[{v}]"
                        for k, v in vertices_with_rank.items()},
                font_color='red',
                font_weight='bold',
            )
        # print help info
        if latest_link:
            plt.text(
                0,
                1,
                f"added {latest_link}",
                color="white",
                fontsize="xx-large",
                transform=ax.transAxes,
            )

        # change background color
        ax.set_facecolor("black")
        fig.set_facecolor("black")
        # show plot
        if not stop_ui:
            plt.draw()
        else:
            plt.show()

    def _build_repr_graph(self):

        # initialize a graph
        g = nx.DiGraph()
        vertices_with_rank = {}

        for i in range(len(self._representatives)):

            # add node for element i
            g.add_node(i)
            # add edge (element->representative)
            g.add_edge(i, self._representatives[i])
            # add rank info
            if self._rank:
                vertices_with_rank[i] = self._rank[i]

        return g, vertices_with_rank
