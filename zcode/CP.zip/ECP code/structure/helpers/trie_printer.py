import matplotlib.pyplot as plt
import networkx as nx
from networkx.drawing.nx_pydot import graphviz_layout


class Trie2D:

    def __init__(self, trie):

        self._trie = trie

    def visualize(self, stop_ui=True):

        # get the 2d graph and other node attributes
        g, vertices_name_mapping, terminators = self._build_repr_graph()

        # plot
        # set figure color
        fig, ax = plt.subplots()
        # 2D graph plot
        nodes_coords = graphviz_layout(g, prog="dot")
        # nodes
        nx.draw_networkx_nodes(
            g,
            nodes_coords,
            node_color=[
                'violet' if v in terminators else 'limegreen' for v in g.nodes
            ],
        )
        # edges
        nx.draw_networkx_edges(
            g,
            nodes_coords,
            edge_color='limegreen',
            arrows=True,
            width=2,
            connectionstyle='arc3',
        )
        # node names
        nx.draw_networkx_labels(
            g,
            nodes_coords,
            labels=vertices_name_mapping,
            font_color="white",
            font_weight='bold',
        )
        # print legend
        if len(terminators) > 0:
            plt.text(
                0,
                1,
                f"\u26ABis_term",
                color="violet",
                fontsize="xx-large",
                transform=ax.transAxes,
            )
        # change background color
        ax.set_facecolor("black")
        fig.set_facecolor("black")
        # show plot
        if not stop_ui:
            plt.draw()
        else:
            plt.show()

    def _build_repr_graph(self):

        # initialize a graph
        g = nx.DiGraph()

        vertices = {}

        # explore the trie
        cn = self._trie._trie

        # don't panic when the trie is empty
        if cn is None:
            return g, {}, set()

        # add the root
        vertices[cn] = cn
        vertices_name_mapping = {cn: "Trie"}
        terminators = set()
        edges = []

        stack = [cn]
        while len(stack) != 0:

            cn = stack.pop()
            for char in cn.children:

                cn_child = cn.children[char]
                stack.append(cn_child)

                vertices[cn_child] = cn_child
                if cn_child.is_term:
                    terminators.add(cn_child)
                vertices_name_mapping[cn_child] = char.upper()
                edges.append((cn, cn_child))

        # add vertices
        for v in vertices:
            g.add_node(v)

        # add edges
        for v1, v2 in edges:
            g.add_edge(v1, v2)

        return g, vertices_name_mapping, terminators
