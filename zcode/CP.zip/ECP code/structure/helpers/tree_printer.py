from collections import deque
import matplotlib.pyplot as plt
import networkx as nx
from math import log2
from networkx.drawing.nx_pydot import graphviz_layout


class BinTree2D:

    def __init__(self, tree):
        self._tree = tree

    def visualize(self, stop_ui=True):

        # get the 2d graph and other node attributes
        g, edge_labels, node_attrs = self._build_repr_graph()

        # plot
        # set figure color
        fig, ax = plt.subplots()
        # 2D graph plot (tree layout)
        nodes_coords = graphviz_layout(g, prog="dot")
        # nodes
        nx.draw_networkx_nodes(
            g,
            nodes_coords,
            node_color='limegreen',
            node_size=1500,
        )
        # edges
        nx.draw_networkx_edges(
            g,
            nodes_coords,
            edge_color='limegreen',
            node_size=1500,
            width=3,
            arrows=True,
            arrowstyle='-|>',
        )
        # node names
        nx.draw_networkx_labels(
            g,
            nodes_coords,
            font_color="white",
            font_weight='bold',
        )
        # edge type
        nx.draw_networkx_edge_labels(
            g,
            nodes_coords,
            edge_labels=edge_labels,
            font_color="red",
            font_weight='bold',
        )
        # add occurences for avl graphs
        if len(node_attrs) != 0:
            labels_pos = dict()
            for node, coords in nodes_coords.items():
                labels_pos[node] = (
                    coords[0],
                    coords[1] - 3 * (2 + log2(len(coords))),
                )
            nx.draw_networkx_labels(
                g,
                labels_pos,
                labels=node_attrs,
                font_color="white",
                font_weight='bold',
            )
        # change background color
        ax.set_facecolor("black")
        fig.set_facecolor("black")
        # show plot
        if not stop_ui:
            plt.draw()
        else:
            plt.show()

    def _build_repr_graph(self):

        # initialize a graph
        g = nx.Graph()
        node_attrs = dict()
        edge_labels = dict()

        # populate the graph
        # (father, child, edge_type)
        tree_edges = deque([(None, self._tree, "")])
        while len(tree_edges) != 0:
            father, child, edge_type = tree_edges.pop()
            # add the child node to the graph
            g.add_node(child._key)
            if hasattr(child, "_duplicates"):
                node_attrs[child._key] = f"[{child._duplicates}]"
            # add the edge father->child to the graph (unless father is None)
            if father is not None:
                g.add_edge(father._key, child._key)
                edge_labels[(father._key, child._key)] = edge_type
            # tree traversal
            if child._right:
                tree_edges.append((child, child._right, "R"))
            if child._left:
                tree_edges.append((child, child._left, "L"))

        return g, edge_labels, node_attrs
