from functools import partial
from typing import Callable


class Runner:

    def __init__(self, obj):

        self._func = partial(self._run, obj)

    def get(self) -> Callable:
        """Returns a personalized test runner for a given object"""

        return self._func

    def _run(self, obj, method_name, verbose=True, **kwargs):
        """Helper to run a method of an object
        
        Args:
            ob (object): Object instance to be tested
            method_name (str): Name of the method to be run
            verbose (bool): Print configuration and object str to stdout
            kwargs (dict): Optional keyword arguments for the method
        """

        if verbose:
            print(f"-----TEST-----")
            # print test params
            print(f"Method:\t{method_name}")
            if kwargs:
                print(f"Params:\t{kwargs}")

        # get method
        m = getattr(obj, method_name)

        # run the test
        result = None
        try:
            result = m(**kwargs)
        except Exception as e:
            print(f"{e}")

        if verbose:
            # print test result
            print(f"Result:\t{result}")
            print(f"str(obj): {obj}\n")
