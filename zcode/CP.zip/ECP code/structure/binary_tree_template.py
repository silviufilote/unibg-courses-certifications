"""This lesson gives an introduction to binary trees. We are going to
learn how to search keys, visit the tree in different ways (in-order,
pre-order, post-order), compute the height of the tree, test whether
the tree is full, how to "reverse" the tree, and finally how to lookup
the lowest common ancestor for two nodes.

About complexity:
- N is the number of keys in the tree
- no implementation of the `insert` method is provided, hence the tree
  may be unbalanced

There are also a couple of additional exercises in the comments.
"""

from collections import deque


class BinTree:

    def __init__(self, key) -> None:
        self._key: int = key
        self._left: BinTree | None = None
        self._right: BinTree | None = None

    def build_sample(self):

        l = BinTree(10)
        r = BinTree(30)
        self._left = l
        self._right = r

        ll = BinTree(7)
        lr = BinTree(12)
        l._left = ll
        l._right = lr

        rl = BinTree(22)
        rr = BinTree(35)
        r._left = rl
        r._right = rr

        lll = BinTree(5)
        llr = BinTree(8)
        ll._left = lll
        ll._right = llr

        lrl = BinTree(11)
        lrr = BinTree(13)
        lr._left = lrl
        lr._right = lrr

        rll = BinTree(21)
        rlr = BinTree(24)
        rl._left = rll
        rl._right = rlr

        rrl = BinTree(34)
        rrr = BinTree(40)
        rr._left = rrl
        rr._right = rrr


if __package__:
    from .helpers.helper import Runner
else:
    from helpers.helper import Runner

# create sample tree
tree = BinTree(20)
tree.build_sample()

# configure test runner
run = Runner(tree).get()

# visualize the tree
if __package__:
    from .helpers.tree_printer import BinTree2D
else:
    from helpers.tree_printer import BinTree2D

BinTree2D(tree).visualize()
