import copy
from random import shuffle, randint
"""Adelson-Velsky Landis Tree (AVL)"""


class AVLNode:

    def __init__(self, key):

        if key is None or not isinstance(key, int) or key < 0:
            raise RuntimeError(
                "Invalid key found, only non-negative integers are accepted")

        self._key: int = key
        self._duplicates: int = 1
        self._left: None | AVLNode = None
        self._right: None | AVLNode = None
        self._height: int = 1

    def balance_factor(self) -> int:
        """Returns the balance factor of the tree"""

        lh = 0 if not self._left else self._left._height
        rh = 0 if not self._right else self._right._height

        return lh - rh

    @staticmethod
    def height(node) -> int:

        if node is None:
            return 0
        elif not isinstance(node, AVLNode):
            raise RuntimeError(f"Undefined `height` for type {type(node)}")

        return node._height


class AVLTree:

    def __init__(self, key):

        self._head: AVLNode = AVLNode(key)

    def get_root(self):

        return self._head

    @staticmethod
    def rot_left(root):
        """Rotates the tree to the left, root._right becomes the new root

        Complexity:
            -S: O(1)
            -T: O(1)
        """

        right = root._right
        tmp = right._left
        right._left = root
        root._right = tmp

        # adjust the height of root and right
        root._height = 1 + max(
            AVLNode.height(root._left),
            AVLNode.height(root._right),
        )
        right._height = 1 + max(
            AVLNode.height(right._left),
            AVLNode.height(right._right),
        )

        return right

    @staticmethod
    def rot_right(root):
        """rotates the tree to the right, root._left becomes the new root

        Complexity:
            -S: O(1)
            -T: O(1)
        """

        left = root._left
        tmp = left._right
        left._right = root
        root._left = tmp

        # adjust the height of root and left
        root._height = 1 + max(
            AVLNode.height(root._left),
            AVLNode.height(root._right),
        )
        left._height = 1 + max(
            AVLNode.height(left._left),
            AVLNode.height(left._right),
        )

        return left

    def insert(self, key):
        """Inserts a new key ensuring that the tree remains balanced"""

        self._head = AVLTree._insert(self._head, key)

    @staticmethod
    def _insert(tree: AVLNode, key) -> AVLNode:
        """Complexity:
            -S: O(log2(N))
            -T: O(log2(N))
        """

        # insertion
        if tree is None:
            return AVLNode(key)
        elif key == tree._key:
            tree._duplicates += 1
            return tree
        elif key < tree._key:
            tree._left = AVLTree._insert(tree._left, key)
        else:
            tree._right = AVLTree._insert(tree._right, key)

        # get the new balance factor
        bf = tree.balance_factor()

        # apply rotations so that bf in {-1; 0; +1}
        if bf in set((-1, 0, +1)):
            # the tree is balanced, just update the height
            tree._height = 1 + max(
                AVLNode.height(tree._left),
                AVLNode.height(tree._right),
            )
        elif bf > 1:
            # left subtree is 'taller'
            if key > tree._left._key:
                tree._left = AVLTree.rot_left(tree._left)
            tree = AVLTree.rot_right(tree)
        else:
            # right subtree is 'taller'
            if key < tree._right._key:
                tree._right = AVLTree.rot_right(tree._right)
            tree = AVLTree.rot_left(tree)

        # remember that rotations modify the structure of the tree
        return tree

    @staticmethod
    def min_node_key_from(root):
        """Complexity:
            -S: O(1)
            -T: O(log2(N))
        """

        cn, pn = root, root
        while cn:
            pn = cn
            cn = cn._left
        return pn

    def delete(self, key):
        """Deletes a key, it also guarantees that tree will be
        balanced after deletion. No errors are raised in case the key
        is not found"""

        self._head = AVLTree._delete(self._head, key)

    @staticmethod
    def _delete(tree: AVLNode | None, key, remove_node=False):
        """Complexity:
            -S: O(log2(N))
            -T: O(log2(N))
        """

        # deletion
        if tree is None:
            return tree
        elif tree._key == key:
            if tree._duplicates > 1 and (not remove_node):
                tree._duplicates -= 1
                return tree
            else:
                if tree._left is None:
                    tmp = tree._right
                    tree = None
                    return tmp
                elif tree._right is None:
                    tmp = tree._left
                    tree = None
                    return tmp
                else:
                    tmp = AVLTree.min_node_key_from(tree._right)
                    tree._key = tmp._key
                    tree._duplicates = tmp._duplicates
                    tree._right = AVLTree._delete(
                        tree._right,
                        tmp._key,
                        remove_node=True,
                    )
        elif tree._key < key:
            tree._right = AVLTree._delete(
                tree._right,
                key,
                remove_node=remove_node,
            )
        else:
            tree._left = AVLTree._delete(
                tree._left,
                key,
                remove_node=remove_node,
            )

        # get the new balance factor
        bf = tree.balance_factor()

        # apply rotations so that balance in {-1; 0; +1}
        if bf in set((-1, 0, +1)):
            # the tree is balanced, just update the height
            tree._height = 1 + max(
                AVLNode.height(tree._left),
                AVLNode.height(tree._right),
            )
        elif bf > 1:
            if tree._left.balance_factor() < 0:
                tree._left = AVLTree.rot_left(tree._left)
            tree = AVLTree.rot_right(tree)
        else:
            if tree._right.balance_factor() > 0:
                tree._right = AVLTree.rot_right(tree._right)
            tree = AVLTree.rot_left(tree)

        return tree


if __package__:
    from .helpers.tree_printer import BinTree2D
else:
    from helpers.tree_printer import BinTree2D

print("Uncomment lines in the code to visualize the impact " \
      + "of insert and delete operations")

# create random keys (with repetitions)
keys = [randint(0, 48) for _ in range(64)]

# shuffle keys
shuffle(keys)

# create the avl tree
tree = AVLTree(keys[0])

# insert key
for key in keys[1:]:
    print(f"Insert key {key}...")
    starting_tree = copy.deepcopy(tree)
    # BinTree2D(starting_tree.get_root()).visualize(stop_ui=False)
    tree.insert(key)
    # BinTree2D(tree.get_root()).visualize()

# delete key (1)
non_existent_key = -1
print("Delete non-existent key ...")
tree.delete(non_existent_key)
print(f"...no errors")

# delete key (2)
deleted_keys = keys[:10]
for key in deleted_keys:
    print(f"Delete key {key}...")
    starting_tree = copy.deepcopy(tree)
    # BinTree2D(starting_tree.get_root()).visualize(stop_ui=False)
    tree.delete(key)
    # BinTree2D(tree.get_root()).visualize()
