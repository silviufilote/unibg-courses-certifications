""""UNION-FIND - Union By Rank + Path Compression"""

E = set([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
L = [
    (0, 1),  # case A
    (2, 1),  # case A
    (3, 2),  # case A    
    (4, 3),  # case A
    (4, 5),  # case A
    (5, 6),  # case A
    (7, 8),  # case B 
    (9, 10),  # case B
    (7, 9),  # case B
    (11, 12),  # case B
    (13, 14),  # case B
    (11, 13),  # case B
    (7, 13),  # case B
    (15, 14),  # NEW LINK
]
P = {}
n = len(E)
representative = [-1 for _ in range(n)]
rank = [-1 for _ in range(n)]


def make_set_ubr_pc(e):

    representative[e] = e
    rank[e] = 0


def find_ubr_pc(e):

    to_compress = []
    while e != representative[e]:
        to_compress.append(e)
        e = representative[e]
    for el in to_compress:
        representative[el] = e
    return e


def union_ubr_pc(e1, e2):
    """Amortized analysis is used to determine the complexity in this
    case (see slides). After M union and find operations on a
    disjoint-set forest with N elements, the runtime is O(M*inv_ack(N)).

    """

    e1 = find_ubr_pc(e1)
    e2 = find_ubr_pc(e2)
    if e1 == e2:
        return
    if rank[e1] == rank[e2]:
        rank[e1] += 1
        representative[e2] = e1
    elif rank[e1] > rank[e2]:
        representative[e2] = e1
    else:
        representative[e1] = e2


if __package__:
    from .helpers.disjoint_set_printer import DisjointSet2D
else:
    from helpers.disjoint_set_printer import DisjointSet2D

# init partitions
for e in E:
    make_set_ubr_pc(e)
# update partitions
for link in L:
    DisjointSet2D(
        representatives=representative,
        rank=rank,
    ).visualize(stop_ui=False)
    e1, e2 = link
    union_ubr_pc(e1, e2)
    DisjointSet2D(
        representatives=representative,
        rank=rank,
    ).visualize(latest_link=(e1, e2))
