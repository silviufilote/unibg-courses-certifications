"""Directed graph with V vertices and E edges"""

from collections import deque

# adjacency map: source -> [list of destinations]
adm = {
    0: [1, 2, 3, 5],  # from vertex 0 to vertices 1, 2, 3, 5
    1: [4, 5],
    2: [7],
    3: [2],
    4: [5],
    5: [0, 1, 6],
    6: [7],
    7: [],
    8: [],
    9: [10],
    10: [11],
    11: [9],
}


def bfs(adm, source):
    """Explores a directed graph with a BFS

    Args:
        adm (Dict[int, List[int]]): adjacency map
        source (int): source node
    """

    print("BFS")

    # ...


def dfs(adm, source):
    """Explores a directed graph with a DFS

    Args:
        adm (Dict[int, List[int]]): adjacency map
        source (int): source node
    """

    print("DFS")

    # ...


# breadth-first search
bfs(adm, 0)

print("---")

# depth-first search
dfs(adm, 0)

# graph visualization
if __package__:
    from .helpers.graph_printer import Graph2D
else:
    from helpers.graph_printer import Graph2D

Graph2D(adm).visualize(directed=True)
