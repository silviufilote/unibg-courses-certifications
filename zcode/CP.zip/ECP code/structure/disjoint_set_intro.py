"""This script introduces the problem of incremental connectivity,
solving it with a naive approach. The goal is to better understand the
problem before studying the disjoint-set structure.

"""

from typing import Dict

print("Incremental Connectivity")

print("===")

E = set([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])
print("We are given a set E of elements:", E)

L = [(13, 14), (12, 13), (11, 12), (10, 11), (7, 8), (6, 7), (5, 6), (5, 10),
     (1, 2), (3, 4), (9, 10), (0, 1), (1, 4)]
print("And a list L of undirected links:", L)

print(
    "The goal is to find the subsets of E with connections between each elements (i.e., the partitions P)"
)

print("===")


def find_partition(P: Dict[int, set], elem: int) -> int | None:
    """Finds the partition that stores `elem`"""

    for pid in P:
        if elem in P[pid]:
            return pid

    # no partition found
    return None


def merge_partitions(P: Dict[int, set], pid1, pid2):
    """Merges two partitions given the identifiers"""

    # pid1 is the bigger partition
    if len(P[pid1]) < len(P[pid2]):
        pid1, pid2 = pid2, pid1
    # merge pid2 into pid1
    P[pid1] = P[pid1].union(P[pid2])
    # delete pid2
    del P[pid2]


def same_partition(P: Dict[int, set], e1, e2) -> bool:
    """Given two elements and a set of partitions, returns True if the
    two elements belong to the same partition"""

    return find_partition(P, e1) == find_partition(P, e2)


def print_partitions(P: Dict[int, set]):
    print("Partitions:")
    for k, v in P.items():
        print(f"\t{k}: {set(v)}")


print(
    "Step 1:",
    "Create single-element partitions",
)
P = {}
for pid, e in enumerate(E):
    pid_to_chr = chr(ord("A") + pid)
    P[pid_to_chr] = set([e])
print_partitions(P)

print("===")

print(
    "Step 2:",
    "Iterate over the links and merge the existing partitions",
)
for step, link in enumerate(L):
    print("---")
    print(f"New link: {link}")
    # get the elements
    e1, e2 = link
    pid1 = find_partition(P, e1)
    pid2 = find_partition(P, e2)
    merge_partitions(P, pid1, pid2)
    print_partitions(P)

print("===")

print(
    "Step 3:",
    "Do e1 and e2 belong to the same partition? (i.e., is there a path between e1 and e2?)"
)

queries = [
    (0, 1),
    (12, 3),
]
for e1, e2 in queries:
    print(f"\t(e1={e1}, e2={e2}) same partition? {same_partition(P, e1, e2)}")

print("===")

print(
    "This approach is inefficient:",
    "\n\t1) need to determine the partition for each element belongs to",
    "\n\t2) each link can potentially cause two sets to be merged",
)
