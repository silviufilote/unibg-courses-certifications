from io import StringIO


class Node:
    """An element in the linked list"""

    def __init__(self, key=None):
        self.key: int | None = key
        self.next_node: Node | None = None

    def __str__(self):
        return str(self.key)


class LinkedList:
    """Linked list implementation"""

    def __init__(self):
        self._head: Node | None = None
        self._len: int = 0

    def __len__(self):
        """Returns the length of the list"""

        return self._len

    def __str__(self):
        """Returns the linked list str representation"""

        if self._head is None:
            return str(None)
        s = StringIO()
        s.write(f"[len {self._len}] ")
        n = self._head
        while n:
            s.write(str(n))
            s.write(" -> ")
            n = n.next_node
        s.write(str(None))
        return s.getvalue()

    def prepend(self, key):
        """Adds a new key at the beginning of the list"""

        nh = Node(key)
        nh.next_node = self._head
        self._head = nh
        self._len += 1

    def append(self, key):
        """Appends a key to the end of the list"""

        n = self._head
        pn = None
        while n:
            pn = n
            n = n.next_node
        if pn is None:
            self._head = Node(key)
        else:
            pn.next_node = Node(key)
        self._len += 1

    def get(self, index, internal_node=False):
        """Returns the key at a given index. Indexes start from
           0. Raises runtime exception if the index falls outside of
           the list. If `internal_node` is True, it returns the node
           storing the key

        """

        if index > self._len - 1:
            raise RuntimeError(f"Index {index} is out of range")

        tmp_index = 0
        cn = self._head

        while tmp_index != index:
            cn = cn.next_node
            tmp_index += 1

        return cn if internal_node else cn.key

    def set_at(self, key, index):
        """Inserts a new key at a given index. Raises runtime
       exception if the index falls outside of the list"""

        if self._len < index:
            raise RuntimeError(f"Index {index} is out of range")

        nn = Node(key)

        if index == 0:
            self.prepend(key)
            return

        cn = self._head
        tmp_index = 0
        while tmp_index < index - 1:
            cn = cn.next_node
            tmp_index += 1

        nn.next_node = cn.next_node
        cn.next_node = nn
        self._len += 1

    def delete_at(self, index):
        """Deletes element at a given index. No error is returned if
        the index is out of range
        """

        if index > self._len - 1:
            return

        n = self._head
        pn = None
        tmp_index = 0
        while tmp_index != index:
            pn = n
            n = n.next_node
            tmp_index += 1
        if pn is None:
            self._head = self._head.next_node
        else:
            pn.next_node = n.next_node
        self._len -= 1

    def reverse(self):
        """Reverses the list (in-place, no new Node allocations)"""

        if self._len <= 1:
            return

        ln = None
        cn = self._head
        rn = self._head.next_node

        while rn:
            cn.next_node = ln
            ln = cn
            cn = rn
            rn = rn.next_node

        cn.next_node = ln
        self._head = cn

    def detect_cycle(self):
        """Returns True if there is a cycle in the list"""

        if self._len == 0:
            return False

        fast = self._head
        slow = self._head

        while fast:
            fast = fast.next_node
            if fast == slow:
                return True
            slow = slow.next_node
            if fast is None:
                break
            fast = fast.next_node
            if fast == slow:
                return True

        return False


"""
Let's test our implementation
"""

# create a linked list
l = LinkedList()

# import the test helper
if __package__ is None:
    from .helpers.helper import Runner
else:
    from helpers.helper import Runner

# get a runner for l
run = Runner(l).get()

# initial test
run("__str__")

# perform some append operations
for i in range(1, 11):
    run("append", key=i)

# submit some get requests
for index in [0, 3, 10]:
    run("get", index=index)

# test prepend
run("prepend", key=111)

# perform some set_at
for key, index in [(77, 20), (77, 0), (78, 7), (79, 13)]:
    run("set_at", key=key, index=index)

# perform some delete_at operations
for index in [20, 0, 6]:
    run("delete_at", index=index)

# other delete_at operations
run("delete_at", index=len(l) - 2)
run("delete_at", index=len(l) - 1)

# reverse the list
run("reverse")

# detect a cycle
run("detect_cycle")

# let's create a cycle in the list
last_index = len(l) - 1
last_node = l.get(last_index, internal_node=True)
second_to_last_node = l.get(last_index - 1, internal_node=True)
last_node.next_node = second_to_last_node
# repeat the test
run("detect_cycle")
# ...
print("...unreachable (because the runner tries to print the list)")
