"""Trie example. You are given a vocabulary and a prefix string. Find
all the words in the vocabulary that start with the given prefix."""


class Node:

    def __init__(self, children: dict, is_term: bool):

        self.children = children
        self.is_term = is_term


class Trie():

    def __init__(self):

        self._trie = None

    def index(self, words: list):
        """
        Creates a Trie given a set of words
        """

        # ...

        pass

    def autocomplete_prefix(self, prefix):
        """Given a prefix, returns all the completion candidates in
        the Trie
        """

        # ...

        pass


# a collection of flowers
flowers = [
    "ACONITUM",
    "ALYSSUM",
    "AGAPANTHUS",
    "ALCHEMILLA",
    "ALSTROEMERIA",
    "ALYSSUM",
    "AMARANTHUS",
    "AMARYLLIS",
    "ANEMONE",
    "ANGELONIA",
    "ANTHURIUM",
    "ANTIRRHINUM",
    "DAHLIA",
    "IRIS",
    "IRIS BLUE",
    "ORCHID",
]
flowers.sort()
print("Flowers:")
for f in flowers:
    print(f"\t{f}")
print()

trie = Trie()
trie.index(flowers)

# import runner and printer
if __package__ is None:
    from .helpers.helper import Runner
    from .helpers.trie_printer import Trie2D
else:
    from helpers.helper import Runner
    from helpers.trie_printer import Trie2D

# get a runner for l
run = Runner(trie).get()

for p in ("A", "AC", "AN", "ORCHID A", "Z", "IRI"):
    run("autocomplete_prefix", prefix=p)

# visualize trie
Trie2D(trie).visualize()
