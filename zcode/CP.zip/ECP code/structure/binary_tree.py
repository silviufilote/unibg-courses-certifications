"""This lesson gives an introduction to binary trees. We are going to
learn how to search keys, visit the tree in different ways (in-order,
pre-order, post-order), compute the height of the tree, test whether
the tree is full, how to "reverse" the tree, and finally how to lookup
the lowest common ancestor for two nodes.

About complexity:
- N is the number of keys in the tree
- no implementation of the `insert` method is provided, hence the tree
  may be unbalanced

There are also a couple of additional exercises in the comments.
"""

from collections import deque


class BinTree:

    def __init__(self, key) -> None:
        self._key: int = key
        self._left: BinTree | None = None
        self._right: BinTree | None = None

    def build_sample(self):

        l = BinTree(10)
        r = BinTree(30)
        self._left = l
        self._right = r

        ll = BinTree(7)
        lr = BinTree(12)
        l._left = ll
        l._right = lr

        rl = BinTree(22)
        rr = BinTree(35)
        r._left = rl
        r._right = rr

        lll = BinTree(5)
        llr = BinTree(8)
        ll._left = lll
        ll._right = llr

        lrl = BinTree(11)
        lrr = BinTree(13)
        lr._left = lrl
        lr._right = lrr

        rll = BinTree(21)
        rlr = BinTree(24)
        rl._left = rll
        rl._right = rlr

        rrl = BinTree(34)
        rrr = BinTree(40)
        rr._left = rrl
        rr._right = rrr

    def search(self, key: int):
        """Returns True if `key` is in the tree

           Complexity:
               -T: O(N) for unbalanced tree, O(log2(N)) for balanced tree
               -S: O(1)
        """

        ct = self
        while ct:
            if ct._key == key:
                return True
            else:
                if key > ct._key:
                    ct = ct._right
                else:
                    ct = ct._left
        return False

    def in_order(self):
        """Returns the keys found in the tree with an in-order visit

           Complexity:
               -T: O(N)
               -S: O(N) for unbalanced tree, O(log2(N)) for balanced tree [consider printing
                        the keys rather than storing them in a list]
        """

        keys = []
        # starting node
        nodes = deque([self])
        # nodes already visited
        open_nodes = dict()
        # tree traversal
        while len(nodes) != 0:
            # read the last node in the stack (without removing it)
            cn = nodes[-1]
            # node already opened? left children already visited
            if open_nodes.get(cn, -1) != -1:
                keys.append(cn._key)
                nodes.pop()
                # move downward-right
                if cn._right:
                    nodes.append(cn._right)
            # new node?
            else:
                # open the node
                open_nodes[cn] = True
                # move downward-left
                if cn._left:
                    nodes.append(cn._left)

        return keys

    def pre_order(self):
        """Returns the keys found in the tree with a pre-order visit"""

        keys = []
        nodes = deque([self])
        while len(nodes) != 0:
            cn = nodes.pop()
            keys.append(cn._key)
            if cn._right:
                nodes.append(cn._right)
            if cn._left:
                nodes.append(cn._left)

        return keys

    def post_order(self):
        """Returns the keys found in the tree with a post-order visit"""

        keys = []
        nodes = deque([self])
        open_nodes = dict()
        while len(nodes) != 0:
            cn = nodes[-1]
            if open_nodes.get(cn, -1) != -1:
                keys.append(cn._key)
                nodes.pop()
            else:
                open_nodes[cn] = True
                if cn._right:
                    nodes.append(cn._right)
                if cn._left:
                    nodes.append(cn._left)

        return keys

    def reverse(self):
        """Reverses key ordering

        Complexity:
           -T: O(N)
           -S: O(N) for unbalanced tree, O(log2(N)) for balanced tree
        """

        nodes = deque([self])
        while len(nodes) > 0:
            cn = nodes.pop()
            cn._left, cn._right = cn._right, cn._left
            if cn._left:
                nodes.append(cn._left)
            if cn._right:
                nodes.append(cn._right)

    def lca(self, ka, kb):
        """Given two keys, write a function that returns the Lowest
          Common Ancestor(LCA). We allow a node to be a descendant of
          itself. The two keys are guaranteed to be stored in the
          tree.

        Complexity:
            -T: O(N) for unbalanced tree, O(log2(N)) for balanced tree
            -S: O(1)

        """

        if not self.search(ka) or not self.search(kb):
            raise RuntimeError("Cannot find an ancestor for missing keys")

        # perform two searches with na and nb
        na = nb = ancestor = self

        while na._key == nb._key:

            ancestor = na

            if ka > na._key:
                na = na._right
            elif ka < na._key:
                na = na._left

            if kb > nb._key:
                nb = nb._right
            elif kb < nb._key:
                nb = nb._left

            if na == nb and na == ancestor:
                break

        return ancestor._key

    def height(self):
        """Returns the height of the tree (height starts from 0)

        Complexity:
           -T: O(N)
           -S: O(N) for unbalanced tree, O(log2(N)) for balanced tree
        """

        h_max = 0
        nodes = deque([(self, 0)])

        while len(nodes) > 0:
            cn, h = nodes.pop()
            h_max = max(h_max, h)
            if cn._left:
                nodes.append((cn._left, h + 1))
            if cn._right:
                nodes.append((cn._right, h + 1))

        return h_max

    def is_full(self):
        """Returns True if the tree is Full. Full tree: each node has either no
        child or 2 children

        Complexity:
           -T: O(N)
           -S: O(N) for unbalanced tree, O(log2(N)) for balanced tree
        """

        nodes = deque([self])
        while len(nodes) > 0:
            cn = nodes.pop()
            if (cn._right and cn._left is None) or (cn._left
                                                    and cn._right is None):
                return False
            if cn._left:
                nodes.append(cn._left)
            if cn._right:
                nodes.append(cn._right)

        return True

    # HOME PRACTICE

    # def is_balanced(self):
    #     """Returns True if the tree is balanced. Balanced tree: for
    #     each node: 1) the left and right subtrees are balanced, and
    #     2) the height of the left and right subtrees differ at most
    #     by 1."""
    #     # write your code here
    #     pass

    # def is_complete(self):
    #     """Returns True if the tree is Complete. Complete tree: each
    #     level in the tree (except the last) has the maximum number
    #     of nodes"""
    #     # write your code here
    #     pass


if __package__:
    from .helpers.helper import Runner
else:
    from helpers.helper import Runner

# create sample tree
tree = BinTree(20)
tree.build_sample()

# configure test runner
run = Runner(tree).get()

# tree visits
for test in ["in_order", "pre_order", "post_order"]:
    run(test)

# lca tests
for ka, kb in [(5, 8), (5, 20), (5, 40), (30, 21)]:
    run("lca", ka=ka, kb=kb)

# tree height
run("height")

# tree shape
run("is_full")

# visualize the tree
if __package__:
    from .helpers.tree_printer import BinTree2D
else:
    from helpers.tree_printer import BinTree2D

BinTree2D(tree).visualize()
