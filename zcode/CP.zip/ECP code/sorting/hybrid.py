if __package__ is None:
    from .insertionsort import insertionsort
    from .quicksort import partition
else:
    from insertionsort import insertionsort
    from quicksort import partition


def hybrid(sequence, start, end):

    while start < end:
        # use insertion sort for short sequences
        if end - start + 1 < 15:
            # ...need a +1 on 'end' for insertion sort
            insertionsort(sequence, start, end + 1)
            break
        # use quick sort for long sequences
        else:
            pivot = partition(sequence, start, end)
            # sort the shorter subsequence first
            if pivot - start < end - pivot:
                hybrid(sequence, start, pivot - 1)
                start = pivot + 1
            else:
                hybrid(sequence, pivot + 1, end)
                end = pivot - 1
