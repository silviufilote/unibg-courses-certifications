"""
Run 'python -m algorithms' to test
"""

import random

from bubblesort import bubblesort
from selectionsort import selectionsort
from insertionsort import insertionsort
from mergesort import mergesort
from quicksort import quicksort
from heapsort import heapsort
from hybrid import hybrid
from radixsort import radixsort    


class SortingAlgorithms:

    def __init__(self):
        # initialize a sequence of random integers
        self.size = int(random.uniform(15, 1500))
        self.sequence = [
            int(random.uniform(0, 1000)) for _ in range(0, self.size)
        ]
        # precompute an oracle
        self.oracle = self.sequence.copy()
        self.oracle.sort()

    def test(self):

        # configurations to be tested
        configurations = {
            bubblesort: {
                "params": None,
                "type": "in-place"
            },
            selectionsort: {
                "params": None,
                "type": "in-place"
            },
            insertionsort: {
                "params": [0, self.size],
                "type": "in-place"
            },
            mergesort: {
                "params": None,
                "type": "not-in-place"
            },
            quicksort: {
                "params": [0, self.size - 1],
                "type": "in-place"
            },
            heapsort: {
                "params": None,
                "type": "in-place"
            },
            radixsort: {
                "params": None,
                "type": "not-in-place"
            },
            hybrid: {
                "params": [0, self.size - 1],
                "type": "in-place"
            },

        }

        for alg, config in configurations.items():
            # prepare a fresh copy of self.sequence
            sequence = self.sequence.copy()
            # retrieve algorithm configuration
            params = config["params"]
            ttype = config["type"]
            match ttype:
                case 'not-in-place':
                    sequence = alg(sequence)
                case 'in-place':
                    alg(sequence) if params is None else alg(sequence, *params)
                case _:
                    raise Exception("Unrecognized configuration")
            # sort the copy with alg, then check the result is correct
            if sequence == self.oracle:
                print(f"{alg.__name__.capitalize()} completed successfully!")
            else:
                print(
                    f"{alg.__name__.capitalize()} didn't sort the values as expected"
                )


SortingAlgorithms().test()
