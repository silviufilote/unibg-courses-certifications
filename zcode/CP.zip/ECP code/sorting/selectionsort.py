def selectionsort(sequence):

    if len(sequence) <= 1:
        return

    for i in range(len(sequence) - 1):

        # get the position of the smallest element in sequence[i:]
        smallest_ep = i
        for j in range(i + 1, len(sequence)):
            if sequence[j] < sequence[smallest_ep]:
                smallest_ep = j

        # swap elements at positions i and smallest_ep
        if smallest_ep != i:
            sequence[i], sequence[smallest_ep] = sequence[
                smallest_ep], sequence[i]
