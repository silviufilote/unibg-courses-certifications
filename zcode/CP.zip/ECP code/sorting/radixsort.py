from typing import List


def countingsort(sequence, radix):
    """Order `sequence` according to `radix`"""

    # number of elements to sort and buckets to use
    size, buckets = len(sequence), [0] * 10

    # virtually separate the elements into buckets
    for i in range(size):
        bucket = (sequence[i] // radix) % 10
        buckets[bucket] += 1

    # cumulate the occurences of the buckets
    for i in range(1, 10):
        buckets[i] += buckets[i - 1]

    # change the order of elements based on the buckets they belong
    new_sequence = [0] * size
    for i in range(size - 1, -1, -1):
        bucket = (sequence[i] // radix) % 10
        buckets[bucket] -= 1
        new_sequence[buckets[bucket]] = sequence[i]

    return new_sequence


def radixsort(sequence: List[int]):

    if len(sequence) <= 1:
        return sequence

    # call countingsort based on the maximum number of radices
    digits = len(str(max(sequence)))
    for radix in range(digits):
        sequence = countingsort(sequence, 10**radix)

    return sequence
