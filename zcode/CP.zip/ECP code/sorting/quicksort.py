def partition(sequence, left, right):
    """The method partition selects a pivot, puts the pivot in the correct
    position, and moves to its left all the elements lower than it

"""
    # select the rightmost element as pivot
    pivot = sequence[right]
    # save the virtual position of the pivot
    i = left

    # move to the left of the pivot all the smaller elements
    for j in range(left, right):
        if sequence[j] <= pivot:
            # element j preceeds the pivot, move it to the left of it (virtually)
            sequence[i], sequence[j] = sequence[j], sequence[i]
            # virtually move the pivot one position to the right
            i = i + 1

    # move the pivot to the correct position (i)
    sequence[i], sequence[right] = sequence[right], sequence[i]

    # return the position of the pivot that was used
    return i


def quicksort(sequence, left, right):

    if left < right:

        # split the sequence into two partitions based on a pivot at position idx
        idx = partition(sequence, left, right)

        # apply quicksort to both partitions
        quicksort(sequence, left, idx - 1)
        quicksort(sequence, idx + 1, right)


"""Can you spot the problem associated with this implementation?

The problem is that 'partition' always selects the righmost element as
the pivot. This could lead to the case in which there are two
partitions long 1 and N-1 elements respectively, respectively. If this
problem keeps repeating every time 'partition' is called, then
'partition' will be called N times.

To solve the problem we can:
1) select a random pivot -> it is unlikely for the previous situation to happen
2) use the median element as pivot

Home exercises:
a) what is the input that triggers the previous problem?
b) does it change something if the middle element is selected as the pivot?
"""
