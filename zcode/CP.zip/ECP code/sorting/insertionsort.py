def insertionsort(sequence, start, end):

    if len(sequence) <= 1:
        return

    for i in range(start, end):

        curr = sequence[i]
        j = i
        # find the location j where curr should be placed, move all
        # the elements greater than curr to the right of curr
        while j > 0 and sequence[j - 1] > curr:  # note: order matters here
            # move forward the element in position j-1
            sequence[j] = sequence[j - 1]
            j -= 1
        else:  # insert curr in the correct position
            sequence[j] = curr
