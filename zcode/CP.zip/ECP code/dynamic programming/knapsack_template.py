"""You are given a list of items. Each item has a weight and a
value. You are also given a knapsack with a maximum capacity, or
rather the maximum weight it can carry.  Determine which of the items
to pack in the knapsack so that the value is maximum.

"""


def knapsack(values, weights, capacity):
    """Returns the maximum value for a knapsack with limited capacity
    """

    # # visualization: table heading
    # print("c:", end="")
    # for c in range(capacity + 1):
    #     print(f"{c:2d} ", end="")
    # print("")

    # ...

    # print("[ ", end="")
    # for v in kns[i % 2]:
    #     print(f"{v:2d} ", end="")
    # print("]")

    # ...

    pass


def run(values, weights, capacity):

    print(f"values: {values}")
    print(f"weights: {weights}")
    print(f"knapsack capacity: {capacity}")
    print(f"knapsack value: {knapsack(values, weights, capacity)}")
    print("-----")


values = [
    [6, 10, 12],
    [6, 6, 6, 6, 6, 10, 12],
    [6, 6, 6, 6, 9, 10, 12],
]
weights = [
    [10, 20, 30],
    [10, 10, 10, 10, 10, 20, 30],
    [5, 5, 5, 5, 2, 8, 15],
]
capacities = [
    50,
    50,
    25,
]

for v, w, c in zip(values, weights, capacities):
    run(v, w, c)
