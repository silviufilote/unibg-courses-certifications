"""You are given an array of coins having different denominations and
an integer amount representing the total money. Return the fewest
number of coins that are needed to make up that sum, or +Inf if it is
impossible. Assume that there is an infinite number of coins for each
denomination.
"""

INF = float("inf")


def coin_change_naive(coins, amount):
    """Returns the minimum number of coins to total the amount. This
    approach is unfeasible even for small amounts, can you guess why?"""

    if amount < 0:
        return INF
    elif amount == 0:
        return 0

    min_coins = INF

    for coin in coins:
        # try to use this coin
        num_coins = 1 + coin_change_naive(coins, amount - coin)
        # check the total number of coins used to total the amount
        min_coins = min(min_coins, num_coins)

    return min_coins


def coin_change_dynamic(coins, amount):
    """Returns the minimum number of coins to total the amount. Also
    returns which coins are used

    Complexity:
        -T: O(Amount*N) [N is the number of coin denominations]
        -S: O(Amount)
    """

    # for each subroblem
    #[
    #  total number of coins used,
    #  a reference to the previous subproblem used,
    #  the additional coin denomination used,
    #]
    amounts = [[0, None, None] for _ in range(amount + 1)]

    # let's compute the coins to total EVERY amount (bottom-up)
    for amount in range(1, amount + 1):
        # initially you don't know how many coins are needed
        amounts[amount] = [INF, None, None]
        # so, try to use all the coins to total the current amount
        for c in range(len(coins)):
            # check coins[c] denomination doesn't exceed amount
            if amount - coins[c] >= 0:
                subamount_coins = amounts[amount - coins[c]][0]
                # if subamount_coins is a finite number
                if subamount_coins != INF:
                    # set the current configuration if it's the best
                    # (this configuration might be overwritten in the
                    # future, if a greater coin denomination is used)
                    if subamount_coins + 1 <= amounts[amount][0]:
                        amounts[amount][0] = subamount_coins + 1
                        amounts[amount][1] = amounts[amount - coins[c]]
                        amounts[amount][2] = coins[c]

    # visualization
    for a, line in enumerate(amounts):
        print(
            f"{a:3d} - {hex(id(line))[7:]}: ",
            f"[nofcoins: {line[0]},\t",
            f"new coin:\t{line[2]},\t",
            f"subproblem: {hex(id(line[1]))[7:]}]",
        )

    # extract the coins
    used_coins = []
    subproblem = amounts[amount]
    while subproblem[1]:
        used_coins.append(subproblem[2])
        subproblem = subproblem[1]

    return (amounts[amount][0], used_coins)


def test(amount, coins):

    print(f"Amount: {amount}")
    print(f"Coins available: {coins}")
    if amount < 40:
        print(f"Number of coins (naive): {coin_change_naive(coins, amount)}")
    print("number of coins (dynamic): {}, coins {}".format(
        *coin_change_dynamic(coins, amount)))
    print("-----")
    input()


# run some tests
coins = [2, 3, 4, 5, 10, 25]
amounts = [1, 7, 8, 17, 19, 28, 34, 39, 101, 103]

for amount in amounts:
    test(amount, coins)
