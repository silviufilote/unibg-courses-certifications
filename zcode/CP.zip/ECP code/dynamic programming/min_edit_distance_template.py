"""The minimum edit distance (Levenshtein) between two strings is the
minimum number of editing operations needed to change the first string
into the other. Valid edit operations consist of insertions, deletions
and substitutions.


Example:
	s1 = "rose"
	s2 = "frost"
	result = 2

"""


def print_subproblems(s1, s2, subproblem):

    n = len(s1)
    m = len(s2)

    print(" " * 5 + "\"" + " " * 3, end="")
    for j in range(1, m + 1):
        print(f"{s2[j-1]:4}", end="")
    print()
    for i in range(n + 1):
        beg = "\"["
        if i != 0:
            beg = f"{s1[i-1]}["
        print(beg, end="")
        for j in range(m + 1):
            print(f"{subproblem[i][j]:>4}", end="")
        print("]")


def med(s1, s2):
    """Returns the minimum number of operations (insert, delete,
    replace) to transform s1 into s2
    """

    print(f"s1: {s1}, s2: {s2}")

    # ...
    pass


strings = (
    ("rose", "frost"),
    ("home", "dome"),
    ("abce", "babce"),
    ("execution", "intention"),
    ("craftsmanship", "partnership"),
)

for s1, s2 in strings:
    med(s1, s2)
