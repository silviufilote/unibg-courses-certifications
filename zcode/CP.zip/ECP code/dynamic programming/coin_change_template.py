"""You are given an array of coins having different denominations and
an integer amount representing the total money. Return the fewest
number of coins that are needed to make up that sum, or +Inf if it is
impossible. Assume that there is an infinite number of coins for each
denomination.
"""

INF = float("inf")


def coin_change_naive(coins, amount):
    """Returns the minimum number of coins to total the amount"""

    # ...
    pass


def coin_change_dynamic(coins, amount):
    """Returns the minimum number of coins to total the amount. Also
    returns which coins are used
    """

    # ...

    # visualization
    # for a, line in enumerate(amounts):
    #     print(
    #         f"{a:3d} - {hex(id(line))[7:]}: ",
    #         f"[nofcoins: {line[0]},\t",
    #         f"new coin:\t{line[2]},\t",
    #         f"subproblem: {hex(id(line[1]))[7:]}]",
    #     )

    # ...

    return [None, None]  # todo: fix


def test(amount, coins):

    print(f"Amount: {amount}")
    print(f"Coins available: {coins}")
    if amount < 40:
        print(f"Number of coins (naive): {coin_change_naive(coins, amount)}")
    print("number of coins (dynamic): {}, coins {}".format(
        *coin_change_dynamic(coins, amount)))
    print("-----")
    input()


# run some tests
coins = [2, 3, 4, 5, 10, 25]
amounts = [1, 7, 8, 17, 19, 28, 34, 39, 101, 103]

for amount in amounts:
    test(amount, coins)
