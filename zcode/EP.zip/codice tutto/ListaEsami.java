package list;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.factories.ListPermutationFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.operators.ListCrossover;
import org.uncommons.watchmaker.framework.operators.ListOrderMutation;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.selection.TruncationSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;

/**
 * rappresentazione con sequenza di 3 interi - i 3 giorni di esame (messi in  ordine)
 * 
 */
public class ListaEsami {

	public static void main(String[] args) {
		
		Random rng = new MersenneTwisterRNG();

		// list of integers
		CandidateFactory<List<Integer>> candidateFactory = new AbstractCandidateFactory<List<Integer>>() {
			// 3 integers da 1 2
			@Override
			public List<Integer> generateRandomCandidate(Random rng) {
				List<Integer> l = new ArrayList<>();
				for (int i = 0; i < 3; i++)
					l.add(rng.nextInt(0, 6)); // excluded the upperlimit
				return l;
			}

		};
		// fitness evaluator
		FitnessEvaluator<List<Integer>> fitnessEvaluator = new FitnessEvaluator<>() {
			@Override
			public boolean isNatural() {
				return true;
			}

			@Override
			public double getFitness(List<Integer> candidate, List<? extends List<Integer>> population) {
				// (opzionali) se non sono ordinati metto la fitness a zero
				ArrayList<Integer> esami = new ArrayList<>(candidate);
				Collections.sort(esami);
				if (!esami.equals(candidate)) return 0;				
				// calcolo del voto (sono sicuramente ordinati)
				ArrayList<Integer> voti = getVoti(candidate);
				// calcolo della media
				if (voti.size() != 3)
					return 0;
				double somma = 0;
				for (Integer voto : voti) {
					somma += voto;
				}
				return somma / 3.0;
			}

		};		
		// prova
		for(int i = 0; i < 20; i++) {
			List<Integer> randomCandidate = candidateFactory.generateRandomCandidate(rng);
			printsolution(randomCandidate);
			System.out.println("        " + fitnessEvaluator.getFitness(randomCandidate, null));
		}
		
		
		// evolutionary operators
		List<EvolutionaryOperator<List<Integer>>> operators = new LinkedList<>();
		operators.add(new ListCrossover<Integer>());
		operators.add(new ListOrderMutation<Integer>());
		EvolutionaryOperator<List<Integer>> pipeline = new EvolutionPipeline<>(operators);
		// SelectionStrategy<? super List<Integer>> selectionStrategy = new
		// RouletteWheelSelection();
		SelectionStrategy<? super List<Integer>> selectionStrategy = new TruncationSelection(0.2);
		EvolutionEngine<List<Integer>> engine = new GenerationalEvolutionEngine<>(candidateFactory, pipeline,
				fitnessEvaluator, selectionStrategy, rng);
		engine.addEvolutionObserver(new EvolutionObserver<List<Integer>>() {
			public void populationUpdate(PopulationData<? extends List<Integer>> data) {
				List<Integer> bestCandidate = data.getBestCandidate();
				System.out.printf("Generation %d: %s %f\n", data.getGenerationNumber(), bestCandidate,
						fitnessEvaluator.getFitness(bestCandidate, null));
			}
		});
		TerminationCondition stop = new GenerationCount(200);
		List<Integer> res = engine.evolve(100, 5, stop);
	}
	// A al giorno 10 e 20, B al giorno 5 e 25, C al giorno 7 e 30.
	//                        0    1    2    3    4   5
	static int giorno[] = {   5,   7,  10,  20,  25, 30 };
	static char corso[] = { 'B', 'C', 'A', 'A', 'B', 'C' };

	private static ArrayList<Integer> getVoti(List<Integer> candidate) {
		// ordino i giorni
		ArrayList<Integer> esami = new ArrayList<>(candidate);
		Collections.sort(esami);
		ArrayList<Character> fatti = new ArrayList<>();
		ArrayList<Integer> voti = new ArrayList<>();
		for (int i = 0; i < esami.size(); i++) {
			int appello = esami.get(i);
			// se ripeto allora esco
			if (fatti.contains(corso[appello]))
				return voti;
			// giorni per studiare?
			int giorni = giorno[appello] - (i == 0 ? 0 : giorno[esami.get(i - 1)]);
			int voto;
			if (giorni <= 5)
				voto = 18;
			else
				voto = 18 + (giorni - 5);
			if (voto >= 30)
				voto = 30;
			voti.add(voto);
			fatti.add(corso[appello]);
		}
		return voti;
	}
	
	
	static void printsolution(List<Integer> candidate){
		ArrayList<Integer> esami = new ArrayList<>(candidate);
		Collections.sort(esami);
		ArrayList<Integer> voti = getVoti(esami);
		for(int i = 0 ; i < esami.size(); i++) {
			String voto = i < voti.size() ? voti.get(i).toString() : "-";
			System.out.print("appello " + esami.get(i) + "(" +corso[esami.get(i)] +")"
			+ " day " + giorno[esami.get(i)]  + " voto " + voto + " ");
		}
		System.out.println();
	}

}
