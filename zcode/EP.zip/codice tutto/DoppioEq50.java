package bitstring;

import java.math.BigInteger;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;

/**
 * rappresentazione con sequenza di bit come intero
 * 
 */
public class DoppioEq50 {

	public static void main(String[] args) {
		//System.out.println(Integer.parseInt("1001111010010101000001110000", 2));
		// 64 bit per rappresentare i double
		CandidateFactory<BitString> candidateFactory = new BitStringFactory(16);
		// evolutionary operators
		List<EvolutionaryOperator<BitString>> operators = new LinkedList<EvolutionaryOperator<BitString>>();
		operators.add(new BitStringCrossover());
		operators.add(new BitStringMutation(new Probability(0.2)));
		EvolutionaryOperator<BitString> pipeline = new EvolutionPipeline<BitString>(operators);
		// fitness evaluator
		// la distanza del doppio da 50 - se 0 la soluzione è corretta, se > 0 devo avvicinarmi
		FitnessEvaluator<BitString> fitnessEvaluator = new FitnessEvaluator<BitString>() {
			@Override
			public double getFitness(BitString candidate, List<? extends BitString> population) {
				// convert to string of bits
				int val = Integer.parseInt(candidate.toString(), 2);
				// 
				return Math.abs(50 - 2 * val);
			}

			@Override
			public boolean isNatural() {
				return false;
			}

		};
		SelectionStrategy<? super BitString> selectionStrategy = new RouletteWheelSelection();
		Random rng = new MersenneTwisterRNG();
		EvolutionEngine<BitString> engine = new GenerationalEvolutionEngine<BitString>(candidateFactory, pipeline,
				fitnessEvaluator, selectionStrategy, rng);
		engine.addEvolutionObserver(new EvolutionObserver<BitString>() {
			public void populationUpdate(PopulationData<? extends BitString> data) {
				BitString bestCandidate = data.getBestCandidate();
				int best = Integer.parseInt(bestCandidate.toString(), 2);
				System.out.printf("Generation %d: %s %d\n", data.getGenerationNumber(), bestCandidate, best);
			}
		});
		TerminationCondition stop = new GenerationCount(200);
		BitString res = engine.evolve(100000, 0, stop);
		System.out.println( Integer.parseInt(res.toString(), 2));

	}

}
