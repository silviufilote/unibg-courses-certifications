package bitstring;

import java.math.BigInteger;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.SteadyStateEvolutionEngine;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.selection.TruncationSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;
import org.uncommons.watchmaker.framework.termination.Stagnation;

/**
 * knapcaks di 4 oggetti
 * 
 * 
 * 
 */
public class KnapSack {

	private static final int PESO = 15;
	static int peso[] = { 7, 2, 1, 9 };
	static int valore[] = { 5, 4, 7, 2 };

	public static void main(String[] args) {
		// 64 bit per rappresentare i double
		CandidateFactory<BitString> candidateFactory = new BitStringFactory(4);
		// evolutionary operators
		// creo una lista - alternativa Arrays.asList
		List<EvolutionaryOperator<BitString>> operators = new LinkedList<>();
		operators.add(new BitStringCrossover(1, new Probability(0.7)));
		operators.add(new BitStringMutation(new Probability(0.2)));
		EvolutionaryOperator<BitString> pipeline = new EvolutionPipeline<>(operators);
		
		// fitness evaluator
		FitnessEvaluator<BitString> fitnessEvaluator = new FitnessEvaluator<>() {
			@Override
			public double getFitness(BitString candidate, List<? extends BitString> population) {
				return calcoloPesoValore(candidate)[1];
			}
			@Override
			public boolean isNatural() {
				return true;
			}

		};
		SelectionStrategy<? super BitString> selectionStrategy = new TruncationSelection(0.25);
		Random rng = new MersenneTwisterRNG();
		EvolutionEngine<BitString> engine = new GenerationalEvolutionEngine<>(
				candidateFactory, pipeline,
				fitnessEvaluator, selectionStrategy, rng);
		engine.addEvolutionObserver(new EvolutionObserver<>() {
			public void populationUpdate(PopulationData<? extends BitString> data) {
				BitString bestCandidate = data.getBestCandidate();
				System.out.printf("Generation %d: %s %f\n", data.getGenerationNumber(), bestCandidate.toString(), data.getBestCandidateFitness());
				System.out.println(" peso " + calcoloPesoValore(bestCandidate)[0]);
			}
		});
		TerminationCondition stop = new Stagnation(50, true);
		BitString res = engine.evolve(5, 0, stop);
	}
	// calcola peso e valore
	private static int[] calcoloPesoValore(BitString candidate) {
		int pesoTot = 0, valTot = 0;
		for (int i = 0; i < candidate.getLength(); i++) {
			if (candidate.getBit(i)) {
				pesoTot += peso[i];
				valTot += valore[i];
				if (pesoTot > PESO) return new int[] {0,0};
			}
		}
		return new int[] {pesoTot,valTot};
	}
	
	private static String covertiAPhenotipo(BitString candidate) {
		String result = "[";
//		for (int i = 0; i < candidate.getLength(); i++) {
//			if (candidate.getBit(i)) {
//				char i - 'D' + 'A'
//			}
//		}
		result += candidate.toString();
		return result;
	}

}
