package bitstring;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;


/* In this section, we will apply the genetic algorithm to a binary string-based optimization problem.
 * The problem is called OneMax and evaluates a binary string based on the number of 1s in the string. 
 * For example, a bitstring with a length of 20 bits will have a score of 20 for a string of all 1s. 
 */

public class OneMax {

	public static void main(String[] args) {
		// 64 bit per rappresentare i double
		CandidateFactory<BitString> candidateFactory = new BitStringFactory(64);
		// evolutionary operators
		List<EvolutionaryOperator<BitString>> operators = new LinkedList<EvolutionaryOperator<BitString>>();
		operators.add(new BitStringCrossover());
		operators.add(new BitStringMutation(new Probability(0.02)));
		EvolutionaryOperator<BitString> pipeline = new EvolutionPipeline<BitString>(operators);
		// fitness evaluator
		FitnessEvaluator<BitString> fitnessEvaluator = new FitnessEvaluator<BitString>() {
			@Override
			public double getFitness(BitString candidate, List<? extends BitString> population) {
				return candidate.countSetBits();
			}

			@Override
			public boolean isNatural() {
				return true;
			}

		};
		SelectionStrategy<? super BitString> selectionStrategy = new RouletteWheelSelection();
		Random rng = new MersenneTwisterRNG();
		EvolutionEngine<BitString> engine = new GenerationalEvolutionEngine<BitString>(candidateFactory, pipeline,
				fitnessEvaluator, selectionStrategy, rng);
		TerminationCondition stop = new GenerationCount(20000);
		engine.addEvolutionObserver(new EvolutionObserver<BitString>() {
			public void populationUpdate(PopulationData<? extends BitString> data) {
				System.out.printf("Generation %d: %s\n", data.getGenerationNumber(), data.getBestCandidate());
			}
		});

		BitString res = engine.evolve(100, 0, stop);
		System.out.println(res.toString());

	}

}
