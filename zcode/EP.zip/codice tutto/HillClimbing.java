package mutatioAdHoc;



import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;


/**
 * We begin by considering a simple one-dimensional geno/phenospace L1 in which
 * individuals consist of a single “trait” expressed as a real number, and their
 * objective fitness is computed via a simple time-invariant function of that
 * real-valued trait. More specifically, an individual is given by <x>and the
 * fitness of individual <x>is defined by the objective fitness function f
 * (x)=50− x2, a simple inverted parabola as depicted graphically in figure 1.1.
 * 
 * 
 * HILL CLIMBING con un numero 
 */

public class HillClimbing {
	
	public static void main(String[] args) {
		// 64 bit per rappresentare i double
		CandidateFactory<Double> candidateFactory = new AbstractCandidateFactory<Double>() {
			@Override
			public Double generateRandomCandidate(Random rng) {
				return rng.nextDouble();
			}			
		};
		// evolutionary operators  ???
		// HILL CLIMBING, 
		EvolutionaryOperator<Double> operator = new EvolutionaryOperator<Double>(){
			@Override
			public List<Double> apply(List<Double> selectedCandidates, Random rng) {
				List<Double> results = new ArrayList<>();
				// for each candidnate sum a numer between -1 and +1
				for(Double d: selectedCandidates) {
					results.add(d + rng.nextDouble(-1, +1));
				}
				return results;
			}
			
		};
		// fitness evaluator
		FitnessEvaluator<Double> fitnessEvaluator = new FitnessEvaluator<Double>() {

			@Override
			public double getFitness(Double candidate, List<? extends Double> population) {
				return Double.max(0,50 - candidate * candidate) ;
			}
			@Override
			public boolean isNatural() {
				return true;
			}
		};
		SelectionStrategy<? super Double> selectionStrategy = new RouletteWheelSelection();
		Random rng = new MersenneTwisterRNG();
		EvolutionEngine<Double> engine = 
				new GenerationalEvolutionEngine<Double>(candidateFactory, operator, 
						fitnessEvaluator, selectionStrategy, rng);
		TerminationCondition stop = new GenerationCount(20);
		engine.addEvolutionObserver(new EvolutionObserver<Double>() {
			public void populationUpdate(PopulationData<? extends Double> data) {
				Double bestCandidate = data.getBestCandidate();
				System.out.printf("Generation %d: %s %f\n", data.getGenerationNumber(), bestCandidate, fitnessEvaluator.getFitness(bestCandidate, null));
			}
		});

		Double res = engine.evolve(1000, 0, stop);
		System.out.println(res.toString());

	}

}
