package wm_lezione;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.factories.StringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.operators.StringCrossover;
import org.uncommons.watchmaker.framework.operators.StringMutation;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;
import org.uncommons.watchmaker.framework.termination.TargetFitness;

public class ProvaBitString {
	public static void main(String[] args) {

		Random rng = new Random();
		//
		CandidateFactory<BitString> candidateFactory = new BitStringFactory(20);

		// operatori di mutazione
		BitStringCrossover c = new BitStringCrossover();
		BitStringMutation m = new BitStringMutation(new Probability(0.2));
		EvolutionPipeline<BitString> ep = new EvolutionPipeline<>(Arrays.asList(c,m));
		
		FitnessEvaluator<BitString> fitness = new FitnessEvaluator<BitString>() {

			@Override
			public double getFitness(BitString candidate, List<? extends BitString> population) {
				return candidate.countSetBits();
			}

			@Override
			public boolean isNatural() {
				return true;
			}
		};
		RouletteWheelSelection selection = new RouletteWheelSelection();
		
        EvolutionEngine<BitString> e = new GenerationalEvolutionEngine<>(
        		candidateFactory, 
        		ep,
        		fitness, 
        		selection, 
        		rng);
        
        e.addEvolutionObserver(new EvolutionObserver<BitString>() {
			@Override
			public void populationUpdate(PopulationData<? extends BitString> data) {
				System.out.print("generazione " + data.getGenerationNumber());
				System.out.print(" best " + data.getBestCandidate());
				System.out.println(" fitness " + data.getBestCandidateFitness());
			}
		});
        BitString best = e.evolve(1000, 0, new GenerationCount(100));
        System.out.println(best);
        
	}

}
