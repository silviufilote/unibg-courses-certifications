package mutatioAdHoc;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.SteadyStateEvolutionEngine;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.selection.TruncationSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;
import org.uncommons.watchmaker.framework.termination.Stagnation;

/**
 * knapcaks di 4 oggetti
 * 
 * 
 * 
 */
public class DivisioneStudenti {

	static class Studente {
		private int cstudio;
		private int cgruppo;

		Studente(int cstudio, int cGruppo) {
			this.cstudio = cstudio;
			this.cgruppo = cGruppo;
		}

		@Override
		public String toString() {
			return "<" + cstudio + "," + cgruppo + ">";
		}

		static Studente[] getLista20Studenti() {
			Studente[] ss = new Studente[20];
			for (int i = 1; i <= 20; i++) {
				ss[i - 1] = new Studente(i, 21 - i);
			}
			return ss;
		}
	}

	public static void main(String[] args) {
		Random rng = new MersenneTwisterRNG();
		// 4 (array) set di studenti per rappresentare la divisione dei 20 studenti
		CandidateFactory<Set<Studente>[]> candidateFactory = new AbstractCandidateFactory<>() {

			@Override
			public Set<Studente>[] generateRandomCandidate(Random rng) {
				// faccio i 4 insieme vuoti
				Set<Studente>[] result = new HashSet[4];
				result[0] = new HashSet<>();
				result[1] = new HashSet<>();
				result[2] = new HashSet<>();
				result[3] = new HashSet<>();
				for (Studente s : Studente.getLista20Studenti()) {
					result[rng.nextInt(4)].add(s);
				}
				return result;
			}
		};
		// fitness evaluator
		FitnessEvaluator<Set<Studente>[]> fitnessEvaluator = new FitnessEvaluator<>() {


			@Override
			public boolean isNatural() {
				return true;
			}

			@Override
			public double getFitness(Set<Studente>[] candidate, List<? extends Set<Studente>[]> population) {
				double d = 0;
				for(Set<Studente> s: candidate) {
					d+= calcolovoto(s);
				}
				return d/4.0;
			}
		};

		
		
		// provo a stampare una popolazione iniziale
		List<Set<Studente>[]> popIn = candidateFactory.generateInitialPopulation(4, rng);
		for (Set<Studente>[] s : popIn) {
			System.out.print("{");
			for(Set<Studente> i : s) 
				System.out.print(i + " " + calcolovoto(i)) ;
			System.out.println("}");
			System.out.println(fitnessEvaluator.getFitness(s, popIn));
		}

		
		// evolutionary operators
		EvolutionaryOperator<Set<Studente>[]> pipeline = new EvolutionaryOperator<>() {
			@Override
			public List<Set<Studente>[]> apply(List<Set<Studente>[]> selectedCandidates, Random rng) {
				List<Set<Studente>[]> results = new ArrayList<>();
				for(Set<Studente>[] i: selectedCandidates) {
					Set<Studente>[] res = new HashSet[4]; 
					res[0] = new HashSet<>(i[0]);
					res[1] = new HashSet<>(i[1]);
					res[2] = new HashSet<>(i[2]);
					res[3] = new HashSet<>(i[3]);
					// seleziono un gruppo a caso
					int gruppo = rng.nextInt(4);
					if (! res[gruppo].isEmpty()) {
						// sposto sempre il primo
						Studente st = res[gruppo].iterator().next();
						res[gruppo].remove(st);
						int newgruppo = (gruppo + rng.nextInt(1,4)) % 4;
						res[newgruppo].add(st);
					}
					results.add(res);
				}
				return results;
			}
		};

		SelectionStrategy<? super Set<Studente>[]> selectionStrategy = new RouletteWheelSelection();
		
		EvolutionEngine<Set<Studente>[]> engine = new GenerationalEvolutionEngine<>(
				candidateFactory, pipeline,
				fitnessEvaluator, selectionStrategy, rng);
		engine.addEvolutionObserver(new EvolutionObserver<Set<Studente>[]>() {
			public void populationUpdate(PopulationData<? extends Set<Studente>[]> data) {
				Set<Studente>[] bestCandidate = data.getBestCandidate();
				System.out.printf("Generation %d: %s %f\n", data.getGenerationNumber(), 
						Arrays.toString(bestCandidate),
						data.getBestCandidateFitness());
			}
		});
		TerminationCondition stop = new Stagnation(50, true);
		Set<Studente>[] res = engine.evolve(100, 5, stop);
	}

	// calcolo del voto del gruppo
	protected static double calcolovoto(Set<Studente> s) {
		if (s.isEmpty()) return 0;
		// guardo quanto è numeroso
		double voto = (s.size() -  5)*.5; 
		// guardo la capacità di studio
		double mediaCstudio = s.stream().mapToDouble(x -> x.cstudio).summaryStatistics().getAverage();
		voto += mediaCstudio  - 10.5;
		// guardo la capacità di lavoro di gruppo
		double mediacgruppo = s.stream().mapToDouble(x -> x.cstudio).average().getAsDouble();
		voto +=  2*(mediacgruppo) - 10.5;
		return voto;
	}

}
