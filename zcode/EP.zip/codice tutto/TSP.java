package wm_lezione;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.factories.ListPermutationFactory;
import org.uncommons.watchmaker.framework.factories.StringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.operators.ListCrossover;
import org.uncommons.watchmaker.framework.operators.ListOrderMutation;
import org.uncommons.watchmaker.framework.operators.StringCrossover;
import org.uncommons.watchmaker.framework.operators.StringMutation;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;
import org.uncommons.watchmaker.framework.termination.TargetFitness;

public class TSP {
	public static void main(String[] args) {

		List<String> cittaDavisitare = Arrays.asList("Bergamo", "Milano", "Torino", "Bologna");
		
		Random rng = new Random();
		// abstract factory -->  possibili elenchi delle mie città (una sola volta ognuno
		CandidateFactory<List<String>> candidateFactory = new ListPermutationFactory<>(cittaDavisitare);

		// operatori di mutazione
		ListOrderMutation<String> m = new ListOrderMutation<>();
		
		FitnessEvaluator<List<String>> fitness = new FitnessEvaluator<>() {

			@Override
			public double getFitness(List<String> candidate, List<? extends List<String>> population) {
				int totDistance = 0;
				for(int i = 0; i < candidate.size()-1; i++) {
					totDistance += distance(candidate.get(i), candidate.get(i+1));
				}
			}
			Map<String, Integer> map = Map.of("Bergamo-Milano", 50, "Bergamo-Torino", 120);

			private int distance(String c1, String c2) {
				Integer d = map.get(c1 + "-" + c2);
				if (d == null) d = map.get(c2 + "-" + c1);
				return d;
			}

			@Override
			public boolean isNatural() {
				return false;
			}
		};
		RouletteWheelSelection selection = new RouletteWheelSelection();
		
        EvolutionEngine<List<String> > e = new GenerationalEvolutionEngine<>(
        		candidateFactory, 
        		ep,
        		fitness, 
        		selection, 
        		rng);
        
        e.addEvolutionObserver(new EvolutionObserver<List<String> >() {
			@Override
			public void populationUpdate(PopulationData<? extends List<String> > data) {
				System.out.print("generazione " + data.getGenerationNumber());
				System.out.print(" best " + data.getBestCandidate());
				System.out.println(" fitness " + data.getBestCandidateFitness());
			}
		});
        List<String>  best = e.evolve(1000, 2, new GenerationCount(100));
        System.out.println(best);
        
	}

}
