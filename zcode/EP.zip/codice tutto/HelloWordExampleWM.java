package helloword_string;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.factories.StringFactory;
import org.uncommons.watchmaker.framework.operators.*;
import org.uncommons.watchmaker.framework.selection.*;
import org.uncommons.watchmaker.framework.termination.GenerationCount;

public class HelloWordExampleWM {

	public static void main(String[] args) {
		CandidateFactory<String> candidateFactory = getCandidateFactory();
		EvolutionaryOperator<String> evolutionaryOperator = getEvolutionaryOperator();
		FitnessEvaluator<String> fitnessEvaluator = new StringEvaluator();
		SelectionStrategy<? super String> selectionStrategy = new RouletteWheelSelection();
		//SelectionStrategy<? super String> selectionStrategy = new TruncationSelection(0.2);
		Random rng = new MersenneTwisterRNG();
		EvolutionEngine<String> engine = new GenerationalEvolutionEngine<>(candidateFactory, evolutionaryOperator,
				fitnessEvaluator, selectionStrategy, rng);
		TerminationCondition stop = new GenerationCount(100);
		engine.addEvolutionObserver(new EvolutionObserver<String>() {
			public void populationUpdate(PopulationData<? extends String> data) {
				System.out.printf("Generation %d: %s\n", data.getGenerationNumber(), data.getBestCandidate());
			}
		});

		String res = engine.evolve(100, 0, stop);
		System.out.println(res);

	}

	private static EvolutionaryOperator<String> getEvolutionaryOperator() {
		char[] chars = new char[27];
		for (char c = 'A'; c <= 'Z'; c++) {
			chars[c - 'A'] = c;
		}
		chars[26] = ' ';
		List<EvolutionaryOperator<String>> operators = new LinkedList<EvolutionaryOperator<String>>();
		operators.add(new StringCrossover());
		operators.add(new StringMutation(chars, new Probability(0.02)));

		EvolutionaryOperator<String> pipeline = new EvolutionPipeline<String>(operators);

		return pipeline;
	}

	static CandidateFactory<String> getCandidateFactory() {
		// Define the set of permitted characters (A-Z plus space).
		char[] chars = new char[27];
		for (char c = 'A'; c <= 'Z'; c++) {
			chars[c - 'A'] = c;
		}
		chars[26] = ' ';
		// Factory for random 11-character Strings.
		CandidateFactory<String> candidateFactory = new StringFactory(chars, 11);
		return candidateFactory;
	}

	// alternativa con una stringa random
	class MyHelloWordInitilCandidateFactory extends AbstractCandidateFactory<String> {

		@Override
		public String generateRandomCandidate(Random rng) {
			String res = "";
			for (int i = 0; i < 11; i++) {
				res += (char) rng.nextInt();
			}
			return res;
		}

	}

	static public class StringEvaluator implements FitnessEvaluator<String> {
		private final String targetString = "HELLO WORLD";

		/**
		 * Assigns one "fitness point" for every character in the candidate String that
		 * matches the corresponding position in the target string.
		 */
		public double getFitness(String candidate, List<? extends String> population) {
			int matches = 0;
			for (int i = 0; i < candidate.length(); i++) {
				if (candidate.charAt(i) == targetString.charAt(i)) {
					++matches;
				}
			}
			return matches;
		}

		public boolean isNatural() {
			return true;
		}
	}

}
