package mutatioAdHoc;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.SteadyStateEvolutionEngine;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.selection.TruncationSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;
import org.uncommons.watchmaker.framework.termination.Stagnation;

/**
 * knapcaks di 4 oggetti
 * 
 * 
 * 
 */
public class KnapSackMyType {

	enum Oggetto {
		A(7, 5), B(2, 4), C(1, 7), D(9, 2);

		private int peso;
		private int valore;

		Oggetto(int peso, int valore) {
			this.peso = peso;
			this.valore = valore;
		}
	}

	private static final int PESO_MAX = 15;

	public static void main(String[] args) {
		// 64 bit per rappresentare i double
		CandidateFactory<Set<Oggetto>> candidateFactory = new AbstractCandidateFactory<Set<Oggetto>>() {

			@Override
			public Set<Oggetto> generateRandomCandidate(Random rng) {
				HashSet<Oggetto> result = new HashSet<>();
				for(Oggetto o: Oggetto.values()) {
					if (rng.nextDouble() > 0.2) result.add(o);
				}
				return result;
			}

		};
		// evolutionary operators
		// creo una lista - alternativa Arrays.asList
		EvolutionaryOperator<Set<Oggetto>> pipeline = new EvolutionaryOperator<>() {

			@Override
			public List<Set<Oggetto>> apply(List<Set<Oggetto>> selectedCandidates, Random rng) {
				List<Set<Oggetto>> result = new ArrayList<>();
				for(Set<Oggetto> s : selectedCandidates) {
					Set<Oggetto> s2 = new HashSet<>(s);
					// add an element random
					if (rng.nextDouble() < 0.1) 
						s2.add(Oggetto.values()[rng.nextInt(Oggetto.values().length)]);
					// or remove
					else if (rng.nextDouble() < 0.1) 
						s2.remove(Oggetto.values()[rng.nextInt(Oggetto.values().length)]);
					result.add(s2);
				}
				return result;
			}
		};

		// fitness evaluator
		FitnessEvaluator<Set<Oggetto>> fitnessEvaluator = new FitnessEvaluator<>() {

			@Override
			public double getFitness(Set<Oggetto> candidate, List<? extends Set<Oggetto>> population) {
				return calcoloPesoValore(candidate)[1];
			}

			@Override
			public boolean isNatural() {
				return true;
			}
		};
		SelectionStrategy<? super Set<Oggetto>> selectionStrategy = new TruncationSelection(0.25);
		Random rng = new MersenneTwisterRNG();
		EvolutionEngine<Set<Oggetto>> engine = new GenerationalEvolutionEngine<>(candidateFactory, pipeline,
				fitnessEvaluator, selectionStrategy, rng);
		engine.addEvolutionObserver(new EvolutionObserver<>() {
			public void populationUpdate(PopulationData<? extends Set<Oggetto>> data) {
				Set<Oggetto> bestCandidate = data.getBestCandidate();
				System.out.printf("Generation %d: %s %f\n", data.getGenerationNumber(), bestCandidate.toString(),
						data.getBestCandidateFitness());
			}
		});
		TerminationCondition stop = new Stagnation(50, true);
		Set<Oggetto> res = engine.evolve(5, 0, stop);
	}

	// calcola peso e valore
	private static int[] calcoloPesoValore(Set<Oggetto> candidate) {
		int pesoTot = 0, valTot = 0;
		for (Oggetto o : candidate) {
			pesoTot += o.peso;
			valTot += o.valore;
			if (pesoTot > PESO_MAX)
				return new int[] { 0, 0 };
		}
		return new int[] { pesoTot, valTot };

	}

}
