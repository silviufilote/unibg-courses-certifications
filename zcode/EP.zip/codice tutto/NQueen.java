package list;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.TerminationCondition;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.factories.ListPermutationFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.operators.ListCrossover;
import org.uncommons.watchmaker.framework.operators.ListOrderMutation;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.selection.TruncationSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;

/**
 * rappresentazione con sequenza di bit come intero
 * 
 */
public class NQueen {

	private static int n = 8;

	public static void main(String[] args) {
		// list of integers
		CandidateFactory<List<Integer>> candidateFactory = new AbstractCandidateFactory<List<Integer>>() {

			// n integers from 1 to n
			@Override
			public List<Integer> generateRandomCandidate(Random rng) {
				List<Integer> l = new ArrayList<>();
				for (int i = 0; i < n; i++)
					l.add(rng.nextInt(1, n + 1)); // excluded the upperlimit
				return l;
			}

		};
		// evolutionary operators
		List<EvolutionaryOperator<List<Integer>>> operators = new LinkedList<>();
		operators.add(new ListCrossover<Integer>());
		operators.add(new ListOrderMutation<Integer>());
		EvolutionaryOperator<List<Integer>> pipeline = new EvolutionPipeline<>(operators);
		// fitness evaluator
		// la distanza del doppio da 50 - se 0 la soluzione è corretta, se > 0 devo
		// avvicinarmi
		FitnessEvaluator<List<Integer>> fitnessEvaluator = new FitnessEvaluator<>() {
			@Override
			public boolean isNatural() {
				return false;
			}

			@Override
			public double getFitness(List<Integer> candidate, List<? extends List<Integer>> population) {
				int clash = 0;
				for (int i = 0; i < candidate.size(); i++) {
					Integer c = candidate.get(i);
					for (int j = i + 1; j < candidate.size(); j++) {
						Integer d = candidate.get(j);
						// same row or in diagonal
						if ((c == d) || Math.abs(c - d) == j - i)
							clash++;
					}
				}
				return clash;
			}

		};
		// SelectionStrategy<? super List<Integer>> selectionStrategy = new
		// RouletteWheelSelection();
		SelectionStrategy<? super List<Integer>> selectionStrategy = new TruncationSelection(0.2);
		Random rng = new MersenneTwisterRNG();
		EvolutionEngine<List<Integer>> engine = new GenerationalEvolutionEngine<>(candidateFactory, pipeline,
				fitnessEvaluator, selectionStrategy, rng);
		engine.addEvolutionObserver(new EvolutionObserver<List<Integer>>() {
			public void populationUpdate(PopulationData<? extends List<Integer>> data) {
				List<Integer> bestCandidate = data.getBestCandidate();
				System.out.printf("Generation %d: %s %f\n", data.getGenerationNumber(), bestCandidate,
						fitnessEvaluator.getFitness(bestCandidate, null));
			}
		});
		TerminationCondition stop = new GenerationCount(200);
		List<Integer> res = engine.evolve(100, 2, stop);
	}

}
