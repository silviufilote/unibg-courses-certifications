package wm_lezione;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.uncommons.maths.binary.BitString;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;
import org.uncommons.watchmaker.framework.factories.BitStringFactory;
import org.uncommons.watchmaker.framework.factories.StringFactory;
import org.uncommons.watchmaker.framework.operators.BitStringCrossover;
import org.uncommons.watchmaker.framework.operators.BitStringMutation;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.operators.ListCrossover;
import org.uncommons.watchmaker.framework.operators.ListOrderMutation;
import org.uncommons.watchmaker.framework.operators.StringCrossover;
import org.uncommons.watchmaker.framework.operators.StringMutation;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.termination.GenerationCount;
import org.uncommons.watchmaker.framework.termination.TargetFitness;

public class NQueen1 {
	public static void main(String[] args) {

		Random rng = new Random();
		// abstract factory --> crea lista di 8 elementi a caso tra 1 e 8
		CandidateFactory<List<Integer>> candidateFactory = new AbstractCandidateFactory<List<Integer>>() {
			@Override
			public List<Integer> generateRandomCandidate(Random rng) {
				List<Integer> candidato = new ArrayList<>(8);
				for(int i = 1; i <= 8; i ++) {
					candidato.add(rng.nextInt(1, 9));
				}
				return candidato;
			}
		};

		// operatori di mutazione
		ListCrossover<Integer> c = new ListCrossover<>();
		ListOrderMutation<Integer> m = new ListOrderMutation<>();
		EvolutionPipeline<List<Integer>> ep = new EvolutionPipeline<>(Arrays.asList(c,m));
		
		FitnessEvaluator<List<Integer>> fitness = new FitnessEvaluator<>() {

			@Override
			public double getFitness(List<Integer> candidate, List<? extends List<Integer>> population) {
				int nClash = 0;
				for(int i = 0; i < candidate.size(); i++) {
					// posizione in colonna i-esima
					int p = candidate.get(i);
					// tutte le altre queen
					for(int j = i+1; j < candidate.size(); j++) {
						// stessa riga
						if (candidate.get(i) == candidate.get(j))
							nClash ++;
						// stessa diagonale
						else if (Math.abs(candidate.get(i) - candidate.get(j)) == j-i)
							nClash ++;
					}
				}
				return nClash;
			}

			@Override
			public boolean isNatural() {
				return false;
			}
		};
		RouletteWheelSelection selection = new RouletteWheelSelection();
		
        EvolutionEngine<List<Integer> > e = new GenerationalEvolutionEngine<>(
        		candidateFactory, 
        		ep,
        		fitness, 
        		selection, 
        		rng);
        
        e.addEvolutionObserver(new EvolutionObserver<List<Integer> >() {
			@Override
			public void populationUpdate(PopulationData<? extends List<Integer> > data) {
				System.out.print("generazione " + data.getGenerationNumber());
				System.out.print(" best " + data.getBestCandidate());
				System.out.println(" fitness " + data.getBestCandidateFitness());
			}
		});
        List<Integer>  best = e.evolve(1000, 2, new GenerationCount(100));
        System.out.println(best);
        
	}

}
